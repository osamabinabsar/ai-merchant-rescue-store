#!/usr/bin/env python3
"""Ingest merchant account statement lines into a normalized statement.csv.

Stdlib only. Deterministic. Fee descriptions map to canonical keys via the
alias table (keep in sync with references/fee-dictionary.md).
"""
from __future__ import annotations

import argparse
import csv
import re
import sys
from pathlib import Path

# Ordered: first match wins. Patterns match the uppercased description.
FEE_ALIASES: list[tuple[str, str]] = [
    (r"PCI\s*(NON|COMP|SCAN|FEE)", "pci_fee"),
    (r"SCAN FEE|SECURITY SCAN", "pci_scan"),
    (r"STMT|STATEMENT|REPORTING", "statement_fee"),
    (r"ANNUAL|MEMBERSHIP", "annual_fee"),
    (r"SVC FEE|SERVICE FEE|MONTHLY FEE|ACCOUNT FEE", "monthly_fee"),
    (r"BATCH|CLOSEOUT", "batch_fee"),
    (r"\bAVS\b|ADDR VERIF", "avs_fee"),
    (r"MIN FEE|MINIMUM|SHORTFALL", "monthly_minimum"),
    (r"GATEWAY", "gateway_fee"),
    (r"CHGBCK|CHARGEBACK|\bCBK\b", "chargeback_fee"),
    (r"TERMINATION|\bETF\b", "early_termination"),
    (r"DISCOUNT|MARKUP|MDR|MERCHANT DISC", "processor_markup"),
    (r"INTERCHANGE|INT CHG|INTCHG|\bINT\b|NABU|ASSESS|SCHEME|\bAPF\b", "interchange"),
]

VOLUME_RE = re.compile(r"SALES|VOLUME|DEPOSITS|CAPTURED", re.I)

FIELDNAMES = ["month", "line_type", "card_type", "present", "description", "fee_key", "amount", "count"]


def map_fee_key(desc: str) -> str | None:
    up = (desc or "").upper()
    for pat, key in FEE_ALIASES:
        if re.search(pat, up):
            return key
    return None


def detect_card_type(desc: str) -> str:
    up = (desc or "").upper()
    if "REWARD" in up:
        return "rewards"
    if "BUSINESS" in up or "B2B" in up:
        return "business"
    if "DEBIT" in up:
        return "debit"
    if "CREDIT" in up or re.search(r"\bVS\b|\bMC\b|\bAMEX\b|\bDISC\b", up):
        return "credit"
    return "unknown"


def detect_present(desc: str) -> str:
    up = (desc or "").upper()
    if re.search(r"\bCP\b|CARD PRESENT", up):
        return "yes"
    if re.search(r"\bCNP\b|KEYED|E-COM|ECOM|ONLINE|INTERNET", up):
        return "no"
    return "unknown"


def money(raw: str) -> float:
    cleaned = re.sub(r"[^0-9.\-]", "", str(raw or ""))
    try:
        return abs(float(cleaned))
    except ValueError:
        return 0.0


def normalize_month(raw: str) -> str:
    raw = (raw or "").strip()
    m = re.search(r"(\d{4})[-/](\d{1,2})", raw)
    if m:
        return f"{m.group(1)}-{int(m.group(2)):02d}"
    m = re.search(r"(\d{1,2})[-/](\d{4})", raw)
    if m:
        return f"{m.group(2)}-{int(m.group(1)):02d}"
    return raw


def read_raw(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    if path.suffix.lower() == ".json":
        import json
        data = json.loads(text)
        return [dict(r) for r in (data if isinstance(data, list) else data.get("lines", []))]
    lines = [l for l in text.splitlines() if l.strip()]
    delim = "\t" if text.count("\t") > text.count(",") else ","
    if "|" in lines[0]:
        delim = "|"
    sample = next(csv.reader([lines[0]], delimiter=delim), [])
    headered = any(h.strip().lower() in ("month", "line_type", "description", "amount") for h in sample)
    rows = []
    if headered:
        for row in csv.DictReader(lines, delimiter=delim):
            rows.append({str(k).strip().lower(): (v or "").strip() for k, v in row.items() if k})
    else:
        for l in lines:
            parts = [p.strip() for p in l.split(delim)]
            if len(parts) >= 3:
                rows.append({"month": parts[0], "description": parts[1], "amount": parts[2]})
            elif len(parts) == 2:
                rows.append({"description": parts[0], "amount": parts[1]})
    return rows


def normalize(row: dict, default_month: str) -> dict | None:
    month = normalize_month(row.get("month", "")) or default_month
    desc = row.get("description", "").strip()
    amount = money(row.get("amount", ""))
    if not desc or amount == 0:
        return None
    fee_key = map_fee_key(desc)
    line_type = (row.get("line_type") or "").strip().lower()
    if not line_type:
        line_type = "fee" if fee_key else ("volume" if VOLUME_RE.search(desc) else "fee")
    if line_type == "volume":
        fee_key = ""
    elif fee_key is None:
        fee_key = "other"
    return {
        "month": month,
        "line_type": line_type,
        "card_type": row.get("card_type", "").strip().lower() or (detect_card_type(desc) if line_type == "volume" else ""),
        "present": row.get("present", "").strip().lower() or (detect_present(desc) if line_type == "volume" else ""),
        "description": desc,
        "fee_key": fee_key,
        "amount": f"{amount:.2f}",
        "count": re.sub(r"[^0-9]", "", str(row.get("count", ""))) or "",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", help="statement file (csv/tsv/json/text)")
    ap.add_argument("--out", default="merchant-audit", help="workspace directory")
    ap.add_argument("--month", default="", help="fallback month (YYYY-MM) when the file has none")
    args = ap.parse_args()

    src = Path(args.input)
    if not src.exists():
        print(f"ERROR: input file not found: {src}", file=sys.stderr)
        return 1

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "out").mkdir(exist_ok=True)

    raw_rows = read_raw(src)
    normalized = [n for n in (normalize(r, args.month) for r in raw_rows) if n]

    register = out_dir / "statement.csv"
    existing: list[dict] = []
    seen: set[tuple] = set()
    if register.exists():
        with register.open(newline="", encoding="utf-8") as fh:
            existing = list(csv.DictReader(fh))
        seen = {(r.get("month"), r.get("line_type"), r.get("description"), r.get("amount")) for r in existing}

    added = skipped = 0
    rows = list(existing)
    for n in normalized:
        key = (n["month"], n["line_type"], n["description"], n["amount"])
        if key in seen:
            skipped += 1
            continue
        seen.add(key)
        rows.append(n)
        added += 1

    with register.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=FIELDNAMES)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in FIELDNAMES})

    unknown = sorted({r["description"] for r in rows if r.get("fee_key") == "other"})
    report = ["# Statement Ingest Report", "",
              f"- Lines added: {added}, duplicates skipped: {skipped}",
              f"- Total normalized lines: {len(rows)}", ""]
    if unknown:
        report.append("## Fee lines needing classification (review queue)")
        report.append("")
        for d in unknown:
            report.append(f"- `{d}` -> currently `other`. Pick a key from references/fee-dictionary.md")
        review_path = out_dir / "out" / "review-queue.csv"
        with review_path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh)
            writer.writerow(["description", "suggested_key", "reason"])
            for d in unknown:
                writer.writerow([d, "other", "no alias matched"])
    else:
        report.append("No unclassified fee lines. Clean statement.")
    (out_dir / "out" / "ingest-report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(f"Ingested {added} line(s), skipped {skipped} duplicate(s). "
          f"{len(unknown)} fee line(s) need classification. Report: {out_dir}/out/ingest-report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
