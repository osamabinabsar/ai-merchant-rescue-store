# Evidence Index Template

One row per evidence item. `evidence_type` keys must match the checklist keys in
`references/reason-codes.md` so `evidence_check.py` can score them.

```csv
dispute_id,evidence_type,path_or_ref,notes
dp_123,receipt,cases/raw/dp123-order-confirmation.pdf,Order #10442
dp_123,delivery,cases/raw/dp123-tracking.png,UPS 1Z999, delivered 2026-09-28
dp_123,customer_communication,cases/raw/dp123-emails.txt,Customer admits receipt on 2026-09-29
dp_123,usage_after,cases/raw/dp123-usage-log.csv,14 logins after delivery
dp_123,terms,cases/raw/terms-checkout.png,Terms shown at checkout
```

Notes on weak vs strong (the scorer marks thin items WEAK):

- `delivery` with no tracking number in notes: weak. Add the carrier scan.
- `customer_communication` without a quote in notes: weak. Put the quote in.
- `usage_after` as a hand-written summary: weak. Export the real log.
- Unknown evidence types are kept but do not score. Map them to a checklist key
  or extend the checklist in `references/reason-codes.md` deliberately.
