# Rate Card — versioned rates with a drift guard

**Why this file exists:** DIY spreadsheets silently keep using last year's
numbers (mileage rate, home-office limits, Section 179). This file is the one
place rates live, every value carries a source and a verified date, and the
skill must refuse to use a stale value silently.

## Drift guard (mandatory)

Before quoting ANY figure below:
1. Compare `verified_date` against today. **If older than 180 days, tell the user
   the value is unverified and confirm against the official source URL.**
2. If the tax year being worked on is newer than the newest verified year here,
   say plainly: "The rate card has not been verified for this year — values below
   are placeholders until confirmed."
3. Never interpolate or "estimate" a new year's rate. Blank means blank.

## US — standard mileage (business use of car)

| Year | Rate / mile | Source | Verified |
|---|---|---|---|
| 2025 | $0.70 | irs.gov Notice 2025-05 (standard mileage) | 2025-01 |
| 2026 | *(unverified — confirm at irs.gov before use)* | irs.gov | — |

- Mileage rate covers gas, depreciation, insurance, maintenance — don't also claim those as separate actual expenses.
- Charity, medical, and moving rates are separate values; this skill only handles the business rate.

## US — home office (simplified method)

| Year | Max sq ft | Rate / sq ft | Source | Verified |
|---|---|---|---|---|
| 2025 | 300 | $5 | irs.gov (simplified method) | 2025-01 |
| 2026 | *(unverified)* | *(unverified)* | irs.gov | — |

## US — other figures that drift

| Item | Value | Year | Source | Verified |
|---|---|---|---|---|
| Section 179 deduction limit | *(confirm)* | 2026 | irs.gov Pub 946 | — |
| Bonus depreciation phase-down | *(confirm)* | 2026 | irs.gov | — |
| Startup cost first-year deduction | *(confirm)* | 2026 | irs.gov | — |
| Standard deduction (for context only) | *(confirm)* | 2026 | irs.gov | — |
| Meals deduction percentage | *(confirm)* | 2026 | irs.gov | — |
| Gift deduction per-recipient cap | *(confirm)* | 2026 | irs.gov | — |
| Independent contractor 1099-NEC threshold | *(confirm)* | 2026 | irs.gov | — |

## UK — simplified expenses (for the UK profile)

| Item | Rate | Source | Verified |
|---|---|---|---|
| Flat rate for working from home (hours/month, band-based) | *(confirm)* | gov.uk simplified expenses | — |
| Business mileage (car/van) | *(confirm)* | gov.uk | — |

## Maintenance log

| Date | Change | By |
|---|---|---|
| 2025-01 | Initial card: 2025 US mileage $0.70, home office simplified $5/sq ft (300 max) | skill author |
| — | Update this table whenever a value is confirmed; bump every `verified_date` | agent/user |

The skill should treat *updating this file correctly* as part of the year-end
ritual in `references/workflow.md` — it is the cheapest, highest-value five
minutes in the whole system.
