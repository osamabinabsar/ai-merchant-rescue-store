---
name: merchant-fee-audit
description: "Audit your credit card processing statement and find the money you are silently overpaying. Parse merchant account statements (CSV or text), compute your true effective rate, break it down by card type, flag junk fees (PCI non-compliance fees, statement fees, monthly minimum shortfalls, batch and AVS fees), compare against benchmark rates, and produce an annualized savings estimate plus a pre-written renegotiation letter with your numbers filled in. Deterministic stdlib Python scripts do the math; every figure traces to a statement line. For small businesses, e-commerce sellers, restaurants, and anyone taking card payments. Use when the user asks about merchant fees, credit card processing fees, interchange fees, payment processing costs, a merchant statement, why processing rates are high, how much they pay in fees, or says \"merchant fees\", \"processing fees\", \"interchange\", \"statement fees\", \"effective rate\", \"payment processor\", \"lower my processing costs\". Do NOT use for legal advice, choosing a processor endorsement, or payment gateway integration."
---

# Merchant Fee Audit

Find the money your payment processor quietly takes. **Parse the statement, compute
the real effective rate, name the junk fees, and hand the user a renegotiation
letter with the numbers already in it.**

Contingency auditors charge 25-50% of recovered savings for exactly this analysis.
This skill does the analysis deterministically and the user keeps 100%.

## The reliability contract (never break these)

1. **No invented numbers.** Every rate, fee, and savings figure comes from
   `scripts/fee_audit.py` output. Never restate totals from memory; re-run the script.
2. **Savings are estimates, labeled as such.** Present the low/high range from the
   audit report. Never promise a specific outcome from a renegotiation.
3. **Fees are classified from the dictionary**, not guessed. Unknown fee lines go
   to the review queue with their raw description; the human decides.
4. **Benchmarks are labeled with their version.** `references/benchmarks.md`
   carries a drift guard; if it is stale, say so before quoting benchmark rates.
5. **No processor endorsements.** Compare numbers; never recommend or disparage a
   named processor. For contract review or early-termination issues, "read the
   contract with a payments attorney" is the answer.

## Workspace

```
merchant-audit/
  raw/                # statements exactly as received (read-only)
  statement.csv       # normalized statement lines (templates/statement-schema.md)
  out/                # audit report, savings estimate, renegotiation letter
```

## Workflow

### Step 1 — Ingest the statement

```bash
python scripts/ingest_statement.py merchant-audit/raw/statement-sep-2026.csv --out merchant-audit/
```

Merchant statement CSVs (summary-line format) and simple text exports are parsed.
Each line becomes either a `volume` line (card sales) or a `fee` line with a
canonical fee key from `references/fee-dictionary.md`. Unknown fee descriptions
are kept verbatim and flagged. Repeat for each monthly statement; the script
appends and de-duplicates.

### Step 2 — Audit

```bash
python scripts/fee_audit.py --statement merchant-audit/statement.csv --out merchant-audit/out/
```

Produces `out/audit-report.md`:
- monthly and annual effective rate (total fees / total volume)
- breakdown by card type where the statement gives it
- every fee classified: NORMAL / NEGOTIABLE / JUNK (removable)
- benchmark comparison with the weighted benchmark rate
- annualized savings estimate as a low/high range
- review queue for unrecognized fee lines (`out/review-queue.csv`)

Read the headline to the user: effective rate, how much above benchmark, and the
annualized gap. Then walk the junk-fee list; each one is a line item they can
challenge tomorrow.

### Step 3 — Renegotiation letter

```bash
python scripts/negotiate_report.py --statement merchant-audit/statement.csv --audit merchant-audit/out/audit-report.md --out merchant-audit/out/
```

Fills `templates/renegotiation-letter.md` with the user's actual numbers:
current effective rate, benchmark target, the specific fees to remove, and the
savings ask. Hand it over and let the human decide who to send it to.

### Step 4 — The follow-through (what makes this pay for itself)

- Suggest a re-audit in 30 days against the next statement to verify any
  negotiated change actually landed. This is where processors quietly backslide.
- If the user takes payments through multiple accounts or a payment facilitator
  (Stripe, Square, PayPal), note those are usually all-in rates: the audit
  compares them against the same benchmarks differently (see the playbook).

## Failure modes to handle explicitly

- **Text-only statement, unknown layout:** show the first lines, propose column
  mapping, confirm with the human, then ingest. Never guess columns silently.
- **Monthly minimum fees:** classify as JUNK only when the shortfall is caused by
  fee level, not by low volume; explain which one it is.
- **Interchange-plus vs flat vs tiered:** identify the pricing model from the
  lines first; the audit report states which model the account uses, because the
  renegotiation tactic differs (see `references/negotiation-playbook.md`).
- **Fee lines that look duplicated:** list them side by side; duplicates happen
  more often than anyone expects.

## References

Load on demand:
- `references/fee-dictionary.md` — fee types, canonical keys, junk or not
- `references/benchmarks.md` — benchmark rates by card type (drift-guarded)
- `references/negotiation-playbook.md` — how to run the renegotiation conversation
