# Chargeback Defense Kit

Turn a payment dispute into a deadline-tracked, checklist-scored, ready-to-submit
representment packet. Built for e-commerce sellers, SaaS founders, and freelancers
who lose disputes to sloppy evidence, not to the facts.

## What it does

1. **Ingest** dispute exports (Stripe CSV, PayPal CSV, generic CSV/JSON) into a
   normalized dispute register. Deadlines computed when missing and labeled ESTIMATED.
2. **Index** your evidence (receipts, delivery confirmations, usage logs, emails).
3. **Score** each dispute against the card-network reason-code checklist
   (Visa 10.4, 13.1, 13.3, 13.7, 13.2, Mastercard 4837/4853). You see exactly
   what is PRESENT, WEAK, or MISSING before you submit anything.
4. **Assemble** the packet: reason-code-specific cover letter, numbered exhibit
   index, and a manifest with the score and deadline.

## Why it is different

Most dispute "tools" are letter templates. This one refuses to let you submit a
weak packet: deterministic stdlib Python does the scoring, every claim in the
cover letter maps to a real exhibit, and the deadline rides on top of every output.

## Requirements

- Python 3.9+ (stdlib only, no dependencies, no network access)
- Works anywhere: Windows, macOS, Linux. Your dispute data never leaves the machine.

## Verify it before trusting it

```bash
python scripts/selfcheck.py
```

Runs the full pipeline against bundled fixtures and prints a pass/fail list.

## Contents

```
SKILL.md                      skill definition for Claude Code / Codex / compatible agents
scripts/ingest_dispute.py     parse + normalize dispute exports
scripts/evidence_check.py     reason-code checklist scoring
scripts/assemble_packet.py    cover letter + exhibit index + manifest
scripts/selfcheck.py          25-check self test
references/reason-codes.md    per-code evidence checklists
references/evidence-playbook.md  what actually wins each dispute type
references/deadlines.md       network response windows (drift-guarded)
templates/                    cover letter, evidence index, register schema
tests/fixtures/               sample dispute + evidence data
```

Not legal advice. It assembles evidence and structures arguments; for
arbitration strategy or legal threats, talk to a payments attorney.
