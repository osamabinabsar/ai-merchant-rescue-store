# Bookkeeping Rescue

**Turn a messy pile of bank statements into tax-ready books** — categorized,
reconciled against your statement balances, and traceable to the source row.

Built for solopreneurs, freelancers, and small businesses who open their
bookkeeping spreadsheet with dread every tax season.

## What you get

- **One clean ledger** from CSV, OFX/QFX, JSON exports, or PDF statement text
- **Rules-based categorization** — decide a merchant once, and it's handled forever
- **A review queue** for ambiguous charges — you approve, nothing is guessed
- **Reconciliation** — duplicate detection, transfer pairing, closing-balance checks
- **P&L, deductions summary, cashflow, and a tax packet** your accountant will love
- **A 10-minute weekly ritual** that makes the annual scramble disappear

## Why it's reliable

The heavy lifting runs through deterministic bundled Python scripts (stdlib
only — nothing to install). Every report number comes from a script, never from
the model's arithmetic. Every transaction keeps its `source_file` and
`source_row`, so any figure can be traced back to the exact statement line.

## Requirements

- An AI agent that supports Agent Skills (Claude, Claude Code, Codex, OpenClaw…)
- Python 3.8+ on the machine (no packages needed)

## Install

- **MCP Market Hub:** install from your Hub and it syncs to your agents automatically.
- **Manual:** drop this folder into your agent's skills directory
  (e.g. `~/.claude/skills/bookkeeping-rescue/`), then restart the agent.

## Quick start

1. Verify the toolchain: `python scripts/selfcheck.py` (25 checks, ~2 seconds).
2. Put statement exports in a `books/raw/` folder.
3. Ask your agent: *"Do my bookkeeping for these statements"* — and confirm your
   tax year and accounts when asked.

## What's inside

| Path | Purpose |
|---|---|
| `SKILL.md` | The workflow the agent follows |
| `scripts/` | ingest · categorize · reconcile · report · selfcheck |
| `references/` | category taxonomy, deduction rules, rate card, bank formats, rituals |
| `templates/` | rules file, ledger schema, PDF mapping example |
| `tests/fixtures/` | sample statements the self-check runs against |

## Important

This skill organizes records and explains general categories. It is **not tax,
legal, or accounting advice** — filing positions and edge cases belong with your
CPA/EA, and the skill builds the question list for exactly that conversation.
