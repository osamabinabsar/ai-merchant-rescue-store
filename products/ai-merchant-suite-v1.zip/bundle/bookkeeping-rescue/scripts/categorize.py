#!/usr/bin/env python3
"""Bookkeeping Rescue - deterministic categorization.

Applies an ordered rules file plus a built-in merchant taxonomy to the ledger.
Nothing is guessed: unmatched rows land in a review queue with keyword evidence,
for a human (assisted by the model) to decide once, then codify as a rule.

Usage:
    python categorize.py --ledger books/ledger.csv --rules books/rules.csv --out books/

Rules file columns:  priority,match_type,match,category,tax_line,note
  match_type: regex | contains | exact   (matched against the normalized description)
  Lower priority number = evaluated first. First match wins.

Output:
    books/ledger.csv          (category/status/confidence columns filled in)
    books/out/review-queue.csv
    books/out/categorize-report.md
"""
import argparse
import csv
import os
import re
import sys

# Built-in merchant taxonomy: normalized-description substring -> (category, tax_line)
TAXONOMY = {
    # Software & subscriptions
    "adobe": ("Software & Subscriptions", "Other business expenses"),
    "openai": ("Software & Subscriptions", "Other business expenses"),
    "anthropic": ("Software & Subscriptions", "Other business expenses"),
    "github": ("Software & Subscriptions", "Other business expenses"),
    "google workspace": ("Software & Subscriptions", "Other business expenses"),
    "google *": ("Software & Subscriptions", "Other business expenses"),
    "microsoft 365": ("Software & Subscriptions", "Other business expenses"),
    "notion": ("Software & Subscriptions", "Other business expenses"),
    "slack": ("Software & Subscriptions", "Other business expenses"),
    "zoom": ("Software & Subscriptions", "Other business expenses"),
    "dropbox": ("Software & Subscriptions", "Other business expenses"),
    "figma": ("Software & Subscriptions", "Other business expenses"),
    "namecheap": ("Software & Subscriptions", "Other business expenses"),
    "godaddy": ("Software & Subscriptions", "Other business expenses"),
    "vercel": ("Software & Subscriptions", "Other business expenses"),
    "aws": ("Software & Subscriptions", "Other business expenses"),
    "cloudflare": ("Software & Subscriptions", "Other business expenses"),
    # Advertising & marketing
    "meta platforms": ("Advertising & Marketing", "Advertising"),
    "facebook": ("Advertising & Marketing", "Advertising"),
    "instagram": ("Advertising & Marketing", "Advertising"),
    "google ads": ("Advertising & Marketing", "Advertising"),
    "google *ads": ("Advertising & Marketing", "Advertising"),
    "tiktok": ("Advertising & Marketing", "Advertising"),
    "linkedin": ("Advertising & Marketing", "Advertising"),
    "mailchimp": ("Advertising & Marketing", "Advertising"),
    "convertkit": ("Advertising & Marketing", "Advertising"),
    "constant contact": ("Advertising & Marketing", "Advertising"),
    # Payment processing (fees only - see notes)
    "stripe": ("Payment Processing Fees", "Commissions and fees"),
    "paypal": ("Payment Processing Fees", "Commissions and fees"),
    "square": ("Payment Processing Fees", "Commissions and fees"),
    "wise": ("Bank & Payment Fees", "Other business expenses"),
    "revolut": ("Bank & Payment Fees", "Other business expenses"),
    # Office & operations
    "amazon": ("Office & Supplies", "Supplies"),
    "staples": ("Office & Supplies", "Supplies"),
    "office depot": ("Office & Supplies", "Supplies"),
    "home depot": ("Repairs & Maintenance", "Repairs and maintenance"),
    "lowes": ("Repairs & Maintenance", "Repairs and maintenance"),
    "ikea": ("Office & Supplies", "Supplies"),
    # Travel & vehicles
    "uber": ("Travel & Vehicles", "Travel"),
    "lyft": ("Travel & Vehicles", "Travel"),
    "shell": ("Travel & Vehicles", "Car and truck expenses"),
    "exxon": ("Travel & Vehicles", "Car and truck expenses"),
    "bp ": ("Travel & Vehicles", "Car and truck expenses"),
    "chevron": ("Travel & Vehicles", "Car and truck expenses"),
    "airbnb": ("Travel & Vehicles", "Travel"),
    "booking.com": ("Travel & Vehicles", "Travel"),
    "expedia": ("Travel & Vehicles", "Travel"),
    "united airlines": ("Travel & Vehicles", "Travel"),
    "delta air": ("Travel & Vehicles", "Travel"),
    # Meals
    "starbucks": ("Meals", "Meals"),
    "mcdonalds": ("Meals", "Meals"),
    "doordash": ("Meals", "Meals"),
    "ubereats": ("Meals", "Meals"),
    "grubhub": ("Meals", "Meals"),
    "restaurant": ("Meals", "Meals"),
    "cafe": ("Meals", "Meals"),
    # Professional services
    "legalzoom": ("Professional Services", "Legal and professional services"),
    "upwork": ("Professional Services", "Contract labor"),
    "fiverr": ("Professional Services", "Contract labor"),
    "toptal": ("Professional Services", "Contract labor"),
    # Telecom
    "verizon": ("Telephone & Internet", "Telephone and internet"),
    "t-mobile": ("Telephone & Internet", "Telephone and internet"),
    "at&t": ("Telephone & Internet", "Telephone and internet"),
    "comcast": ("Telephone & Internet", "Telephone and internet"),
    "xfinity": ("Telephone & Internet", "Telephone and internet"),
    # Banking noise -> transfers/fees
    "transfer": ("Transfers (exclude from P&L)", "Not an expense"),
    "payment thank you": ("Credit Card Payment (transfer)", "Not an expense"),
    "credit card payment": ("Credit Card Payment (transfer)", "Not an expense"),
    "transfer to": ("Transfers (exclude from P&L)", "Not an expense"),
    "zelle": ("Transfers (exclude from P&L)", "Not an expense"),
    "venmo": ("Transfers (exclude from P&L)", "Not an expense"),
    "atm withdrawal": ("Owner Draw / Cash", "Not deductible by default"),
    "interest charge": ("Bank & Payment Fees", "Other business expenses"),
    "service charge": ("Bank & Payment Fees", "Other business expenses"),
    "wire fee": ("Bank & Payment Fees", "Other business expenses"),
    "foreign transaction": ("Bank & Payment Fees", "Other business expenses"),
    "refund": ("Refunds & Returns", "Income offset"),
}

# Fallback heuristics: regex -> (category, tax_line, confidence)
HEURISTICS = [
    (r"\b(inc|llc|ltd|corp)\b.*\b(payroll|salary)\b", "Payroll", "Wages", 0.8),
    (r"\brent\b", "Rent", "Rent or lease", 0.75),
    (r"\b(utility|utilities|electric|water bill|gas bill)\b", "Utilities", "Utilities", 0.75),
    (r"\b(insurance|premium)\b", "Insurance", "Insurance", 0.75),
    (r"\b(course|udemy|coursera|training|workshop|conference)\b",
     "Education & Training", "Other business expenses", 0.7),
    (r"\b(domain|hosting|vps|server)\b", "Software & Subscriptions", "Other business expenses", 0.7),
    (r"\b(shipping|usps|ups |fedex|dhl)\b", "Shipping & Postage", "Shipping and postage", 0.7),
    (r"\b(printing|staples|vistaprint)\b", "Office & Supplies", "Supplies", 0.7),
]

EXPENSE_HINTS = re.compile(
    r"\b(supply|supplies|fee|fees|subscription|monthly|annual|payment|purchase|bill|order)\b", re.I)


def norm(s):
    return (s or "").strip().lower()


def load_rules(path):
    rules = []
    if path and os.path.exists(path):
        with open(path, "r", encoding="utf-8", newline="") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                match = (row.get("match") or "").strip()
                if not match:
                    continue
                rules.append({
                    "priority": int(row.get("priority") or 100),
                    "match_type": (row.get("match_type") or "contains").strip().lower(),
                    "match": match,
                    "category": (row.get("category") or "Review").strip(),
                    "tax_line": (row.get("tax_line") or "").strip(),
                    "note": (row.get("note") or "").strip(),
                })
    rules.sort(key=lambda r: r["priority"])
    return rules


def apply_rules(desc, rules):
    d = norm(desc)
    for rule in rules:
        mt, m = rule["match_type"], rule["match"]
        try:
            if mt == "regex" and re.search(m, d, re.I):
                return rule["category"], rule["tax_line"], 0.95, "rule:{}".format(m)
            if mt == "exact" and d == norm(m):
                return rule["category"], rule["tax_line"], 0.95, "rule:{}".format(m)
            if mt == "contains" and norm(m) in d:
                return rule["category"], rule["tax_line"], 0.95, "rule:{}".format(m)
        except re.error:
            continue
    return None


def apply_taxonomy(desc):
    d = norm(desc)
    best = None
    for key, (cat, tax) in sorted(TAXONOMY.items(), key=lambda kv: -len(kv[0])):
        if key in d:
            best = (cat, tax, 0.9, "taxonomy:{}".format(key))
            break
    return best


def apply_heuristics(desc):
    for pattern, cat, tax, conf in HEURISTICS:
        if re.search(pattern, norm(desc), re.I):
            return cat, tax, conf, "heuristic"
    return None


def main(argv=None):
    ap = argparse.ArgumentParser(description="Bookkeeping Rescue - categorization")
    ap.add_argument("--ledger", required=True)
    ap.add_argument("--rules", default=None, help="rules.csv path")
    ap.add_argument("--out", required=True)
    args = ap.parse_args(argv)

    rules = load_rules(args.rules)
    out_dir = os.path.abspath(args.out)
    os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)

    with open(args.ledger, "r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        fieldnames = reader.fieldnames
        rows = list(reader)

    review, counts = [], {}
    for row in rows:
        if row.get("category") and row.get("status") in ("auto", "approved"):
            counts[row["category"]] = counts.get(row["category"], 0) + 1
            continue
        desc = row.get("description", "")
        result = (apply_rules(desc, rules) or apply_taxonomy(desc) or apply_heuristics(desc))
        if result:
            cat, tax, conf, via = result
            row["category"] = cat
            row["status"] = "auto"
            row["confidence"] = "{:.2f}".format(conf)
            if tax and not row.get("notes"):
                row["notes"] = "tax_line:{}".format(tax)
            counts[cat] = counts.get(cat, 0) + 1
        else:
            row["category"] = "UNREVIEWED"
            row["status"] = "review"
            row["confidence"] = "0.00"
            review.append(row)
            counts["UNREVIEWED"] = counts.get("UNREVIEWED", 0) + 1

    with open(args.ledger, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    review_path = os.path.join(out_dir, "out", "review-queue.csv")
    review_cols = ["txn_id", "date", "description", "amount", "account", "source_file"]
    with open(review_path, "w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=review_cols, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(review)

    lines = ["# Categorize Report", "",
             "Rules applied: **{}** ordered rules + merchant taxonomy + heuristics.".format(len(rules)),
             "", "| Category | Rows |", "|---|---|"]
    for cat, n in sorted(counts.items(), key=lambda kv: -kv[1]):
        lines.append("| {} | {} |".format(cat, n))
    lines += ["",
              "Review queue: **{}** rows -> `out/review-queue.csv`".format(len(review)),
              "",
              "Human decisions on review rows should be saved as new rules in "
              "`rules.csv` so each decision is made exactly once."]
    report_path = os.path.join(out_dir, "out", "categorize-report.md")
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    print("Categorized {} rows ({} need review)".format(len(rows), len(review)))
    print("Report: {}".format(report_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
