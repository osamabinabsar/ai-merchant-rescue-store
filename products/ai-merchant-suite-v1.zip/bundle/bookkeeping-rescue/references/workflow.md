# Workflow — the rituals that make tax season boring

The catch-up (Phase 1–4 in SKILL.md) fixes the past. These rituals fix the
future. Offer them at the end of every catch-up — the skill's retention depends
on the user adopting the rhythm, not just the dump.

## The 10-minute weekly close

Same slot every week (Friday afternoon works for most people). While the memory
of each charge is still fresh:

1. Drop the week's statement rows / receipts into `books/raw/`.
2. `python scripts/ingest.py` on anything new (30 seconds).
3. `python scripts/categorize.py` (30 seconds).
4. Clear the review queue: answer "what was this?" while you still know. Every
   answer becomes a rule, so recurring merchants never ask twice.
5. Glance at `out/reconciliation-report.md`. Done.

**Why weekly beats monthly:** a charge categorized the day it happened takes
five seconds; the same charge eleven months later is archaeology. The busiest
month is always the month with least free time — decoupling capture (instant)
from categorizing (weekly) is what keeps the system alive in crunch time.

## The monthly close (15 minutes, first week of the month)

1. Ingest last month fully; confirm the row count matches the statement.
2. Run `reconcile.py` with closing balances from each statement:
   `--closing "Chase Checking=2026-01-31:9323.06"`
3. Review the transfer-pair warnings: confirm each is a real own-account move.
4. Skim `report.py`'s monthly P&L column. A wrong category is obvious while the
   month is recent.
5. File receipts for anything over $75 into `books/receipts/YYYY-MM/`.

## The year-end packet (60–90 minutes, once a year)

1. Import anything missing; make `reconcile.py` exit clean.
2. Zero out the review queue. No UNREVIEWED rows leave the building.
3. **Update `references/rate-card.md`** — confirm the new year's rates, bump
   `verified_date`, log the change. This kills silent rule drift.
4. Run `report.py --year YYYY` and read `tax-packet.md` end to end.
5. Fill in the "Questions for your CPA" checkboxes with real questions.
6. Hand the packet + `ledger.csv` + receipt folder to the accountant.

The measure of success: the accountant says the books are clean and the user
never opened a spreadsheet with dread.

## Rolling habit tips (share with the user)

- One business account + one card for everything business deletes an entire
  category of work (sorting personal from business).
- Photograph receipts at purchase; one line of context ("hardware store, job at
  5th street") is the part a bookkeeper cannot reconstruct later.
- Recurring subscriptions: create one rule each; they are the easiest 20% of the
  ledger and the most commonly miscategorized (personal streaming!).
- If the user has multiple businesses, run separate `books/` folders per entity
  and never merge ledgers — entity separation is what keeps liability protection
  and clean books intact.
