# Reason Code Evidence Checklists

Version: 2026-10. Card network rules change. The `--drift-guard` in
`evidence_check.py` warns when this file is older than the check date by more
than 12 months. Verify codes against current Visa/Mastercard dispute rules
before relying on them for a large dispute.

Format for each code: what the cardholder claims, and the checklist items that
`evidence_check.py` scores. Item keys match `evidence_type` values in
`evidence-index.csv`.

## GENERIC (unknown code)

Cardholder claim: unspecified problem with the transaction.

| Key | Item | Weight |
|---|---|---|
| receipt | Itemized receipt or order confirmation showing what was bought | 2 |
| proof_of_service | Evidence the product or service was delivered | 2 |
| customer_communication | Any customer message about the order | 1 |
| terms | Terms of service or refund policy the customer agreed to | 1 |

## VISA-10.4 (Fraud, card-absent environment)

Cardholder claims they did not authorize the purchase.

| Key | Item | Weight |
|---|---|---|
| avs_match | AVS match result from the processor | 2 |
| cvv_match | CVV verification result | 2 |
| ip_device | IP address and device fingerprint used at purchase | 2 |
| account_history | Prior undisputed purchases from the same account | 2 |
| usage_after | Login or usage activity after the purchase date | 2 |
| delivery | Delivery to the billing address or a verified address | 1 |
| customer_communication | Customer referenced the purchase in messages | 1 |

## VISA-13.1 (Product or service not received)

| Key | Item | Weight |
|---|---|---|
| delivery | Tracking with delivery confirmation to the billing address | 3 |
| proof_of_service | Download logs, access logs, or service activation record | 2 |
| receipt | Order confirmation with expected delivery terms | 1 |
| customer_communication | Messages showing the customer knew the item shipped | 1 |

## VISA-13.3 (Not as described or defective)

| Key | Item | Weight |
|---|---|---|
| product_description | Pre-purchase description, photos, or spec sheet | 2 |
| terms | Return and refund policy shown at checkout | 2 |
| customer_communication | Messages where the customer describes the issue | 2 |
| proof_of_service | Evidence the product matches the description | 2 |
| refund_attempt | Record of a refund offered, refused, or completed | 1 |

## VISA-13.7 (Canceled merchandise or service)

| Key | Item | Weight |
|---|---|---|
| terms | Cancellation policy agreed to at signup or checkout | 3 |
| usage_after | Usage or access after the claimed cancellation date | 2 |
| customer_communication | Messages showing the customer continued or declined cancel | 2 |
| receipt | Billing terms the customer accepted | 1 |

## MASTERCARD-4837 (No cardholder authorization)

Same shape as VISA-10.4. Score against the VISA-10.4 checklist.

## MASTERCARD-4853 (Cardholder dispute: goods not received or not as described)

Split by sub-condition:
- Not received: use the VISA-13.1 checklist.
- Not as described: use the VISA-13.3 checklist.
Log which sub-condition in `evidence-index.csv` notes.

## VISA-13.2 / MASTERCARD-4834 (Duplicate processing / paid by other means)

| Key | Item | Weight |
|---|---|---|
| transaction_records | Both transaction records showing distinct orders or one reversal | 3 |
| receipt | Receipts for each charge | 2 |
| customer_communication | Messages showing two separate purchases | 1 |

## STRIPE-fraudulent / generic processor fraud labels

Map to VISA-10.4 unless the processor names a network code.

## Notes

- Weights feed the 0-100 score in `evidence_check.py`. Minimum viable packet:
  score >= 60 and no MISSING item with weight >= 3. Below that, recommend
  gathering more evidence before submitting.
- "WEAK" means the item exists but is thin (for example a delivery note with no
  tracking number). The playbook has upgrades for common weak items.
