#!/usr/bin/env python3
"""Bookkeeping Rescue - self check.

Runs the full pipeline (ingest -> categorize -> reconcile -> report) against the
bundled fixtures and asserts the expected outcomes. Run this right after
installing the skill to prove the toolchain works in this environment.

Usage:
    python scripts/selfcheck.py

Exit code 0 = all checks pass.
"""
import csv
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURES = os.path.join(os.path.dirname(HERE), "tests", "fixtures")

CHECKS = []


def check(name, ok, detail=""):
    CHECKS.append((name, ok, detail))
    print("[{}] {}{}".format("PASS" if ok else "FAIL", name,
                             " — " + detail if detail and not ok else ""))


def run(script, *argv):
    return subprocess.run([sys.executable, os.path.join(HERE, script)] + list(argv),
                          capture_output=True, text=True)


def main():
    if not os.path.isdir(FIXTURES):
        print("fixtures missing: {}".format(FIXTURES))
        return 1

    tmp = tempfile.mkdtemp(prefix="books-rescue-")
    books = os.path.join(tmp, "books")
    os.makedirs(books, exist_ok=True)

    try:
        # ---- ingest: CSV, JSON, OFX
        r = run("ingest.py", os.path.join(FIXTURES, "sample_bank.csv"),
                "--account", "Chase Checking", "--out", books, "--year", "2026", "--date-order", "us")
        check("ingest csv runs", r.returncode == 0, r.stderr[-300:])
        r = run("ingest.py", os.path.join(FIXTURES, "sample_card.json"),
                "--account", "Amex Card", "--out", books, "--year", "2026")
        check("ingest json runs", r.returncode == 0, r.stderr[-300:])
        r = run("ingest.py", os.path.join(FIXTURES, "sample.ofx"),
                "--account", "Bank OFX", "--out", books, "--year", "2026")
        check("ingest ofx runs", r.returncode == 0, r.stderr[-300:])

        ledger = os.path.join(books, "ledger.csv")
        with open(ledger, "r", encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh))
        check("ledger has rows", len(rows) >= 24, "got {}".format(len(rows)))
        check("all rows have source provenance",
              all(r["source_file"] and r["source_row"] for r in rows))
        check("amounts normalized to 2dp floats",
              all(re.match(r"^-?\d+\.\d{2}$", r["amount"]) for r in rows))
        dates_ok = all(re.match(r"^\d{4}-\d{2}-\d{2}$", r["date"]) for r in rows)
        check("dates normalized to ISO", dates_ok)

        # dedupe: re-ingest same file, expect zero new rows
        r = run("ingest.py", os.path.join(FIXTURES, "sample_bank.csv"),
                "--account", "Chase Checking", "--out", books, "--year", "2026", "--date-order", "us")
        with open(ledger, "r", encoding="utf-8", newline="") as fh:
            rows2 = list(csv.DictReader(fh))
        check("re-ingest adds no duplicates", len(rows2) == len(rows),
              "{} -> {}".format(len(rows), len(rows2)))

        # ---- categorize
        rules = os.path.join(books, "rules.csv")
        r = run("categorize.py", "--ledger", ledger, "--rules", rules, "--out", books)
        check("categorize runs", r.returncode == 0, r.stderr[-300:])
        with open(ledger, "r", encoding="utf-8", newline="") as fh:
            rows = list(csv.DictReader(fh))
        auto = [x for x in rows if x["status"] == "auto"]
        review = [x for x in rows if x["status"] == "review"]
        check("most rows auto-categorized", len(auto) >= len(rows) * 0.6,
              "auto {} of {}".format(len(auto), len(rows)))
        check("unmatched rows go to review queue", all(x["category"] == "UNREVIEWED" for x in review))
        stripe = [x for x in rows if "stripe" in x["description"].lower()]
        check("merchant taxonomy works (stripe -> fees)",
              all("Payment Processing" in x["category"] for x in stripe) and bool(stripe))
        chase_pmt = [x for x in rows if "credit card payment" in x["description"].lower()]
        check("card payment classified as transfer",
              all("transfer" in x["category"].lower() for x in chase_pmt) and bool(chase_pmt))

        # ---- reconcile (should WARN on transfers/unreviewed but not FAIL)
        r = run("reconcile.py", "--ledger", ledger, "--out", books)
        check("reconcile exits clean (no FAIL)", r.returncode == 0, r.stdout[-300:])
        rec = os.path.join(books, "out", "reconciliation-report.md")
        with open(rec, "r", encoding="utf-8") as fh:
            rec_text = fh.read()
        check("transfer suspicion detected", "internal transfer" in rec_text)
        check("reconcile reports unreviewed rows", "need human categorization" in rec_text)

        # ---- report
        out = os.path.join(books, "out")
        r = run("report.py", "--ledger", ledger, "--out", out, "--year", "2026")
        check("report runs", r.returncode == 0, r.stderr[-300:])
        for name in ("pnl.md", "pnl.csv", "deductions.md", "cashflow.md", "tax-packet.md"):
            check("artifact {}".format(name), os.path.exists(os.path.join(out, name)))
        with open(os.path.join(out, "pnl.csv"), "r", encoding="utf-8", newline="") as fh:
            pnl = list(csv.reader(fh))
        check("pnl has categories", len(pnl) >= 4, "rows {}".format(len(pnl)))
        with open(os.path.join(out, "tax-packet.md"), "r", encoding="utf-8") as fh:
            packet = fh.read()
        check("tax packet has CPA question list", "Questions for your CPA" in packet)
        check("tax packet disclaims advice", "not constitute tax advice" in packet)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    failed = [c for c in CHECKS if not c[1]]
    print("\n{} checks, {} failed".format(len(CHECKS), len(failed)))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
