# Category Taxonomy — Chart of Accounts ↔ Tax Lines

A single classification spine so every report, export, and CPA handoff uses the
same words. Categories are the *books* view; tax lines are the *return* view.
Keep both; never mix them in one column.

## Master categories → US Schedule C (Form 1040) tax lines

| Category (books) | Schedule C line (US) | Notes |
|---|---|---|
| Advertising & Marketing | Line 8 Advertising | Ads, listings, promo swag, directory fees |
| Payment Processing Fees | Line 10 Commissions and fees | Stripe/PayPal/Square fees |
| Bank & Payment Fees | Line 27a Other expenses | Wire fees, FX fees, account fees |
| Office & Supplies | Line 18 Supplies | Consumables, small equipment under capitalization threshold |
| Software & Subscriptions | Line 27a Other expenses | SaaS, hosting, domains, AI tools |
| Telephone & Internet | Line 25 Utilities (or 27a) | Business % only; mixed personal → allocate |
| Utilities | Line 25 Utilities | |
| Rent | Line 20b Rent or lease (business property) | Office/shop rent; home office → Form 8829 |
| Repairs & Maintenance | Line 21 Repairs and maintenance | Repairs, not improvements |
| Travel & Vehicles | Line 24a Travel / 24b Car and truck | Meals inside travel split out to Meals |
| Meals | Line 24b Meals | Generally 50% deductible (verify current-year rule) |
| Professional Services | Line 17 Legal and professional | Lawyers, accountants, consultants |
| Contract Labor | Line 11 Contract labor | 1099 contractors; watch 1099-NEC filing duties |
| Payroll | Line 26 Wages | Wages, employer taxes, benefits |
| Insurance | Line 15 Insurance | Business insurance; not health (Schedule 1) |
| Education & Training | Line 27a Other expenses | Courses, conferences, books in trade |
| Shipping & Postage | Line 27a Other expenses | |
| Interest | Line 16b Mortgage / 16a Other | Business loan/credit-card interest |
| Refunds & Returns | Income offset | Reduces gross receipts |
| Transfers (exclude from P&L) | Not an expense | Own-account moves; never deductible |
| Credit Card Payment (transfer) | Not an expense | Paying a card bill is not an expense; the charges are |
| Owner Draw / Cash | Not deductible by default | Owner transfers; ATM cash needs receipts |
| UNREVIEWED | — | Blocks clean reporting; resolve first |

## Non-US profiles

- **UK self-assessment:** map to "allowable expenses" categories (office costs, travel, staff, advertising, insurance, bank charges, legal/accountancy, rent/rates, utilities, phone/internet). Meals are usually disallowed except on qualifying business travel.
- **Generic / cash-basis:** keep the books categories, leave `tax_line` blank, and let the accountant map at year end.

## Tie-breaker rules

1. **Substance over label.** "AMAZON" could be supplies, equipment, or personal — ask if the amount is material (> 1% of monthly expense) and the description is ambiguous.
2. **Split, don't squeeze.** A mixed receipt gets two rows (e.g., 70% Supplies / 30% Owner Draw) with a `note: split <reason>`. Adjust `amount` on the two rows so they sum to the original — the ledger stays additive.
3. **Personal is not a category of last resort.** Personal spend in a business account goes to `Owner Draw / Cash` (or a `Personal` category) so P&L stays clean.
4. **Card payments are not expenses.** The individual charges already were. Classify the payment as `Credit Card Payment (transfer)`.
5. **When in doubt → UNREVIEWED.** A visible gap is safe; a confident wrong guess is not.
