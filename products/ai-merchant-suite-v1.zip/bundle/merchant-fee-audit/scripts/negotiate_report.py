#!/usr/bin/env python3
"""Fill templates/renegotiation-letter.md with the user's actual audit numbers.

Reads out/audit-data.json produced by fee_audit.py. Never estimates into the
letter: unknown values are written as "not available".
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from datetime import date, timedelta
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--audit", default="merchant-audit/out/audit-data.json")
    ap.add_argument("--out", default="merchant-audit/out")
    ap.add_argument("--merchant-name", default="your business")
    ap.add_argument("--contact-name", default="account manager")
    args = ap.parse_args()

    audit_path = Path(args.audit)
    if not audit_path.exists():
        print(f"ERROR: audit data not found: {audit_path}. Run fee_audit.py first.", file=sys.stderr)
        return 1
    data = json.loads(audit_path.read_text(encoding="utf-8"))

    junk = [k for k, v in data.get("fee_totals", {}).items() if v.get("classification") == "JUNK"]
    junk_list = ", ".join(sorted(junk)) if junk else "none identified"
    months = data.get("months", [])
    period = f"{months[0]['month']} to {months[-1]['month']}" if months else "the covered period"
    reply_by = (date.today() + timedelta(days=10)).isoformat()

    fee_totals = data.get("fee_totals", {})
    markup = fee_totals.get("processor_markup", {}).get("total")
    savings_range = (f"${data['savings_low']:,.0f} - ${data['savings_high']:,.0f}"
                     if data.get("savings_low") is not None else "not available")

    template_path = Path(__file__).resolve().parent.parent / "templates" / "renegotiation-letter.md"
    if not template_path.exists():
        print(f"ERROR: template not found: {template_path}", file=sys.stderr)
        return 1
    letter = template_path.read_text(encoding="utf-8")

    replacements = {
        "{{account_tail}}": "on file",
        "{{contact_name}}": args.contact_name,
        "{{period_covered}}": period,
        "{{annual_volume}}": f"${data.get('annual_volume', 0):,.0f}",
        "{{annual_fees}}": f"${data.get('annual_fees', 0):,.0f}",
        "{{effective_rate}}": f"{data.get('effective_rate', 'not available')}%",
        "{{benchmark_rate}}": f"{data.get('benchmark_rate', 'not available')}%",
        "{{junk_fee_list}}": junk_list,
        "{{savings_estimate}}": savings_range,
        "{{target_markup}}": "not available (ask for an interchange-plus quote)",
        "{{target_per_txn}}": "$0.10 or less",
        "{{reply_by_date}}": reply_by,
        "{{merchant_name}}": args.merchant_name,
        "{{merchant_contact}}": "contact on file",
    }
    for k, v in replacements.items():
        letter = letter.replace(k, v)

    if "---\n\nAssembly rules" in letter:
        letter = letter.split("---\n\nAssembly rules")[0].rstrip() + "\n"

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / "renegotiation-letter.md"
    out_path.write_text(letter, encoding="utf-8")

    leftover = re.findall(r"\{\{[^}]+\}\}", letter)
    if leftover:
        print(f"WARNING: unfilled placeholders remain: {', '.join(sorted(set(leftover)))}")
    print(f"Renegotiation letter written: {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
