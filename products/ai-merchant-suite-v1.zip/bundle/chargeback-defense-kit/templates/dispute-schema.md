# Dispute Register Schema (cases.csv)

Written by `ingest_dispute.py`; also hand-editable.

| Column | Type | Meaning |
|---|---|---|
| dispute_id | text | Processor's dispute/case ID |
| order_id | text | Your internal order or invoice ID |
| amount | decimal | Disputed amount |
| currency | text | ISO code (USD, EUR, ...) |
| reason_code | text | Normalized, e.g. `VISA-10.4`, `GENERIC` |
| claim_summary | text | One-line summary of the cardholder's claim |
| opened_on | date | Date the dispute was opened (ISO) |
| respond_by | date | Submission deadline (ISO). Computed ones are marked ESTIMATED in reports |
| source | text | stripe / paypal / square / generic |
| status | text | open / submitted / won / lost / expired |
| submitted_on | date | When the representment was sent (blank until then) |

## Normalized reason codes

The ingest script maps common processor labels to network codes:

| Input label | Normalized |
|---|---|
| fraudulent, fraud, unauthorized | VISA-10.4 (or MASTERCARD-4837 when the network is known) |
| product_not_received, not_received | VISA-13.1 |
| product_unacceptable, not_as_described | VISA-13.3 |
| subscription_canceled, canceled | VISA-13.7 |
| duplicate | VISA-13.2 |
| unrecognized / anything else | GENERIC |

If the export carries an explicit network code (like `visa_10.4`), that wins.
