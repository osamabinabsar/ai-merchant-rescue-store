---
name: chargeback-defense-kit
description: "Turn a payment dispute (chargeback) into a winning representment: parse the dispute export (Stripe, PayPal, or CSV/JSON), compute the response deadline, score your evidence against the card-network reason-code checklist, list exactly what is missing, and assemble a ready-to-submit evidence packet with a reason-code-specific cover letter. Deterministic stdlib Python scripts do the checking, so nothing is guessed and every claim traces to a source record. For e-commerce sellers, SaaS founders, and freelancers fighting Stripe/PayPal/Shopify disputes. Use when the user has a chargeback, dispute, \"friendly fraud\", a Stripe dispute, needs to respond to a dispute, win a chargeback, gather dispute evidence, or says \"chargeback\", \"dispute\", \"representment\", \"reason code\", \"evidence packet\", \"dispute deadline\", \"payment reversed\". Do NOT use for legal advice, court litigation, or fraud prevention strategy."
---

# Chargeback Defense Kit

Turn a dispute into a **deadline-tracked, checklist-scored, ready-to-submit representment packet**.

Disputes are not won by writing a nicer letter. They are won by submitting the exact
evidence the reason code demands, before the clock runs out, in a packet the
arbitrator can scan in 30 seconds. This skill enforces all three.

## The reliability contract (never break these)

1. **No guessed deadlines.** The respond-by date comes from the dispute record, or
   from the network default in `references/deadlines.md` (with the source labeled).
   If the deadline is within 48 hours, say so loudly and put it at the top of everything.
2. **No invented evidence.** Every evidence item is a real file or record the user
   provided. Never claim a delivery confirmation exists unless it does.
3. **Checklist over vibes.** Evidence sufficiency is scored by
   `scripts/evidence_check.py` against the reason-code checklist. Present the
   scorecard; never assert "this is strong evidence" without the score behind it.
4. **One packet per dispute.** `assemble_packet.py` output is the submission.
   If it is not in the packet, it is not in the case.
5. **No legal advice.** You assemble evidence and structure arguments. For
   arbitration strategy, merchant-account legal threats, or "should I sue",
   the answer is: talk to a payments attorney. Put it in the packet's open questions.

## Case workspace

```
cases/
  raw/                # dispute exports and evidence files exactly as received
  cases.csv           # normalized dispute register (templates/dispute-schema.md)
  evidence-index.csv  # what evidence exists per dispute (templates/evidence-index.example.csv)
  out/                # scorecards, packets
```

## Workflow

### Step 1 — Ingest the dispute

```bash
python scripts/ingest_dispute.py cases/raw/stripe-disputes.csv --source stripe --out cases/
```

Stripe CSV exports, PayPal CSV, and generic CSV/JSON are recognized. The script
normalizes reason codes to `NETWORK-CODE` form (for example `VISA-10.4`), computes
the respond-by date when the export omits it, and writes `cases/cases.csv` plus
`out/ingest-report.md`. Read the report to the user: how many disputes, which are
urgent, total money at stake.

### Step 2 — Index the evidence

Walk the user's evidence (order records, delivery confirmations, emails, chat logs,
screenshots) and log each item in `cases/evidence-index.csv`:

```csv
dispute_id,evidence_type,path_or_ref,notes
dp_123,delivery_confirmation,cases/raw/dp123-tracking.png,Signed at front desk
dp_123,customer_communication,cases/raw/dp123-emails.txt,Customer admits receipt
```

If evidence is missing, say what is missing after Step 3 tells you what the
reason code demands. Do not pad the index with wishes.

### Step 3 — Score against the reason code

```bash
python scripts/evidence_check.py --cases cases/cases.csv --evidence cases/evidence-index.csv --out cases/out/
```

Produces `out/evidence-scorecard.md` per dispute: each checklist item from
`references/reason-codes.md` marked PRESENT / MISSING / WEAK, an overall score,
and the deadline. Then apply `references/evidence-playbook.md` to choose the
strongest argument order for the items that are present.

### Step 4 — Assemble the packet

```bash
python scripts/assemble_packet.py --case dp_123 --cases cases/cases.csv --evidence cases/evidence-index.csv --out cases/out/
```

Builds `out/packet-dp_123/` containing:
- `cover-letter.md` from `templates/cover-letter.md`, reason-code-specific,
  every sentence tied to an evidence exhibit
- `evidence-index.md` with exhibits numbered and captioned
- `manifest.json` with the score, deadline, and file list (the submission checklist)

Present the cover letter to the user, walk through the missing items (if any),
and let the human decide whether to submit now or hunt for more evidence first.

### Step 5 — Submit and log

The user submits through Stripe/PayPal/Shopify. Record the submission date in
`cases/cases.csv` (`status` and `submitted_on`). Offer to set a follow-up for the
network's decision window.

## Failure modes to handle explicitly

- **Deadline already passed:** say it immediately. A post-deadline packet is
  usually refused; discuss the processor's appeal path instead.
- **Reason code unknown or generic:** use the `GENERIC` checklist and ask the
  user for the code from the processor dashboard. Never guess a code.
- **Evidence contradicting the customer's claim is missing:** list the gap and
  the 2-3 most likely places to find it (fulfillment logs, carrier API exports,
  IP/device logs, signed receipts).
- **Friendly fraud pattern (customer claims fraud but used the product):**
  use the usage/login evidence items in the playbook; this pattern is winnable
  and is the most commonly abandoned one.

## References

Load on demand:
- `references/reason-codes.md` — checklists per network reason code
- `references/evidence-playbook.md` — what wins each dispute category
- `references/deadlines.md` — network response windows with drift guard
