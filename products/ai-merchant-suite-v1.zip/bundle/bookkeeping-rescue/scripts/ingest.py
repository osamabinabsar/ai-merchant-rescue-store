#!/usr/bin/env python3
"""Bookkeeping Rescue - statement ingestion.

Parse bank/credit-card statement exports (CSV/TSV, OFX/QFX, JSON, or column-mapped
text extracted from PDF statements) into one normalized, deduplicated ledger.

Stdlib only. Deterministic. Every output row keeps source_file + source_row.

Usage:
    python ingest.py FILE [FILE ...] --out books/ [--account NAME] [--year YYYY]
                      [--date-order auto|us|eu] [--map mapping.json]

Output:
    books/ledger.csv        (appended; header written if missing)
    books/out/ingest-report.md
"""
import argparse
import csv
import hashlib
import json
import os
import re
import sys
from datetime import datetime

LEDGER_COLUMNS = [
    "txn_id", "date", "description", "amount", "currency", "account",
    "memo", "source_file", "source_row", "category", "status", "confidence", "notes",
]

DATE_FORMATS = [
    "%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y", "%m-%d-%Y", "%d-%m-%Y",
    "%m/%d/%y", "%d/%m/%y", "%d %b %Y", "%b %d, %Y", "%d %B %Y", "%B %d, %Y",
    "%Y%m%d", "%b %d %Y", "%d.%m.%Y", "%m.%d.%Y",
]

MONTHS = {m.lower() for m in [
    "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec",
    "january", "february", "march", "april", "may", "june", "july", "august",
    "september", "october", "november", "december"]}


# ---------------------------------------------------------------- helpers

def norm_header(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


DATE_HEADERS = {"date", "transactiondate", "posteddate", "postdate", "valuedate",
                "transactedon", "bookingdate", "dates", "created", "createdat",
                "timestamp", "time", "transactedat", "postedat"}
DESC_HEADERS = {"description", "details", "payee", "memo", "name", "narrative",
                "transactiondescription", "reference", "merchant", "particulars"}
AMOUNT_HEADERS = {"amount", "amountusd", "value", "net", "transactionamount"}
DEBIT_HEADERS = {"debit", "withdrawal", "withdrawals", "debitamount", "moneyout",
                 "paidout", "dr", "outflow", "spend"}
CREDIT_HEADERS = {"credit", "deposit", "deposits", "creditamount", "moneyin",
                  "paidin", "cr", "inflow"}
BALANCE_HEADERS = {"balance", "runningbalance", "closingbalance", "availablebalance"}
CURRENCY_HEADERS = {"currency", "curr", "ccy"}
MEMO_HEADERS = {"memo", "notes", "note", "checknumber", "checkno"}


def parse_amount(raw, date_order="auto"):
    """Parse a money string into float. Handles $1,234.56 / (50.00) / 1.234,56 / -12,5 EUR."""
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg, s = True, s[1:-1]
    s = re.sub(r"[^0-9,.\-+]", "", s)
    if s in ("", "-", "+"):
        return None
    if s.startswith("-"):
        neg, s = True, s[1:]
    elif s.startswith("+"):
        s = s[1:]
    # European decimal comma: 1.234,56 or 1234,56
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        parts = s.split(",")
        if len(parts) == 2 and len(parts[1]) in (1, 2):
            s = s.replace(",", ".")
        else:
            s = s.replace(",", "")
    try:
        val = float(s)
    except ValueError:
        return None
    return -val if neg else val


def parse_date(raw, date_order="auto"):
    if raw is None:
        return None
    s = str(raw).strip()
    if not s:
        return None
    s = s.split("T")[0].strip()
    # OFX style 20260331 or 20260331120000
    m = re.match(r"^(\d{8})(\d{6})?$", s)
    if m:
        s = m.group(1)
    candidates = DATE_FORMATS
    if date_order == "us":
        candidates = [f for f in DATE_FORMATS if not f.startswith("%d/%m")] + \
                     ["%m/%d/%Y", "%m/%d/%y"]
    elif date_order == "eu":
        candidates = ["%d/%m/%Y", "%d/%m/%y", "%d.%m.%Y"] + \
                     [f for f in DATE_FORMATS if not f.startswith("%m/")]
    for fmt in candidates:
        try:
            dt = datetime.strptime(s, fmt)
            if dt.year < 1900 or dt.year > 2100:
                continue
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def fingerprint(date, desc, amount, account):
    base = "{}|{}|{:.2f}|{}".format(date, (desc or "").strip().lower(), amount or 0.0, account)
    return hashlib.sha1(base.encode("utf-8")).hexdigest()[:16]


def normalize_desc(raw):
    d = re.sub(r"\s+", " ", (raw or "").strip())
    d = re.sub(r"[*#]{2,}", " ", d)
    return d.strip(" -")


# ---------------------------------------------------------------- formats

def parse_csv_file(path, account, date_order):
    """Yield dicts: date, description, amount, currency, memo, source_row, raw."""
    rows = []
    with open(path, "r", encoding="utf-8-sig", errors="replace", newline="") as fh:
        sample = fh.read(8192)
        fh.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        try:
            has_header = csv.Sniffer().has_header(sample)
        except csv.Error:
            has_header = True
        reader = csv.reader(fh, dialect)
        all_rows = [r for r in reader if any(c.strip() for c in r)]
    if not all_rows:
        return rows
    header_idx = 0
    cols = {}
    if has_header:
        header = [norm_header(c) for c in all_rows[0]]
        for i, h in enumerate(header):
            if h in DATE_HEADERS and "date" not in cols:
                cols["date"] = i
            elif h in DESC_HEADERS and "desc" not in cols:
                cols["desc"] = i
            elif h in AMOUNT_HEADERS and "amount" not in cols:
                cols["amount"] = i
            elif h in DEBIT_HEADERS and "debit" not in cols:
                cols["debit"] = i
            elif h in CREDIT_HEADERS and "credit" not in cols:
                cols["credit"] = i
            elif h in BALANCE_HEADERS and "balance" not in cols:
                cols["balance"] = i
            elif h in CURRENCY_HEADERS and "currency" not in cols:
                cols["currency"] = i
            elif h in MEMO_HEADERS and "memo" not in cols:
                cols["memo"] = i
        if "date" in cols:
            header_idx = 1
    if "date" not in cols:
        # headerless or unrecognized: guess by content (col0 = date-like)
        cols = {"date": 0, "desc": None, "amount": None}
        probe = all_rows[0]
        for i, cell in enumerate(probe):
            if parse_date(cell, date_order) and "date" not in cols.values() or i == 0:
                pass
        cols["date"] = 0
        # find first money-like column after date
        for i, cell in enumerate(probe):
            if i == 0:
                continue
            if parse_amount(cell) is not None:
                cols["amount"] = i
                break
        cols["desc"] = 1 if len(probe) > 1 else None
        header_idx = 0

    for ridx, row in enumerate(all_rows[header_idx:], start=header_idx + 1):
        def cell(name):
            i = cols.get(name)
            return row[i] if i is not None and i < len(row) else None

        date = parse_date(cell("date"), date_order)
        if date is None:
            continue
        amount = parse_amount(cell("amount"))
        if amount is None:
            debit = parse_amount(cell("debit")) or 0.0
            credit = parse_amount(cell("credit")) or 0.0
            if debit or credit:
                amount = credit - abs(debit)
        if amount is None:
            continue
        rows.append({
            "date": date,
            "description": normalize_desc(cell("desc")),
            "amount": round(float(amount), 2),
            "currency": (cell("currency") or "").strip().upper() or None,
            "memo": (cell("memo") or "").strip() or None,
            "balance": parse_amount(cell("balance")),
            "source_row": ridx,
        })
    return rows


OFX_TXN_TAGS = ["DTPOSTED", "TRNAMT", "FITID", "NAME", "MEMO", "TRNTYPE", "CURRENCY"]


def parse_ofx_file(path):
    rows = []
    with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
        text = fh.read()
    currency = None
    m = re.search(r"<CURSYM>\s*([A-Z]{3})", text)
    if m:
        currency = m.group(1)
    stmt = re.search(r"<STMTTRN>(.*?)</STMTTRN>", text, re.S)
    blocks = re.findall(r"<STMTTRN>(.*?)</STMTTRN>", text, re.S)
    if not blocks and stmt:
        blocks = [stmt.group(1)]
    for bidx, block in enumerate(blocks, start=1):
        fields = {}
        for tag in OFX_TXN_TAGS:
            fm = re.search(r"<{tag}>\s*([^\r\n<]*)".format(tag=tag), block)
            if fm:
                fields[tag] = fm.group(1).strip()
        date = parse_date(fields.get("DTPOSTED", "")[:8], "auto")
        amount = parse_amount(fields.get("TRNAMT"))
        if date is None or amount is None:
            continue
        desc = normalize_desc(fields.get("NAME") or fields.get("MEMO") or "")
        memo = fields.get("MEMO") if fields.get("MEMO") != desc else None
        rows.append({
            "date": date, "description": desc, "amount": round(float(amount), 2),
            "currency": currency, "memo": memo, "balance": None, "source_row": bidx,
        })
    return rows


def _walk_json(obj, out):
    """Find transaction-like objects anywhere in a JSON structure."""
    if isinstance(obj, dict):
        keys = {norm_header(k) for k in obj}
        if keys & (DATE_HEADERS | AMOUNT_HEADERS | DEBIT_HEADERS | CREDIT_HEADERS):
            out.append(obj)
        for v in obj.values():
            _walk_json(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _walk_json(v, out)


def parse_json_file(path, date_order):
    with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
        data = json.load(fh)
    found = []
    _walk_json(data, found)
    rows = []
    for ridx, obj in enumerate(found, start=1):
        def pick(*names):
            for k, v in obj.items():
                if norm_header(k) in names:
                    return v
            return None
        date = parse_date(pick(*DATE_HEADERS), date_order)
        amount = parse_amount(pick(*AMOUNT_HEADERS))
        if amount is None:
            debit = parse_amount(pick(*DEBIT_HEADERS)) or 0.0
            credit = parse_amount(pick(*CREDIT_HEADERS)) or 0.0
            if debit or credit:
                amount = credit - abs(debit)
        if date is None or amount is None:
            continue
        rows.append({
            "date": date,
            "description": normalize_desc(pick(*DESC_HEADERS)),
            "amount": round(float(amount), 2),
            "currency": (pick(*CURRENCY_HEADERS) or None),
            "memo": pick(*MEMO_HEADERS), "balance": None, "source_row": ridx,
        })
    return rows


def parse_mapped_text(path, map_spec, date_order):
    """Parse extracted PDF text using a mapping spec.

    map formats:
      {"format": "regex", "line": "^(?P<date>...)\\s+(?P<desc>...)\\s+(?P<amount>...)$"}
      {"format": "columns", "columns": [[0,10],[10,40],[40,55]], "fields": ["date","desc","amount"]}
    """
    rows = []
    with open(path, "r", encoding="utf-8-sig", errors="replace") as fh:
        lines = [ln.rstrip("\n") for ln in fh]
    fmt = map_spec.get("format", "regex")
    n = 0
    for lidx, line in enumerate(lines, start=1):
        if not line.strip():
            continue
        rec = None
        if fmt == "regex":
            m = re.search(map_spec["line"], line)
            if m:
                rec = {k: v for k, v in m.groupdict().items()}
        else:
            spans = map_spec["columns"]
            fields = map_spec["fields"]
            rec = {}
            for (start, end), field in zip(spans, fields):
                rec[field] = line[int(start):int(end)]
        if not rec:
            continue
        date = parse_date(rec.get("date"), date_order)
        amount = parse_amount(rec.get("amount"))
        if date is None or amount is None:
            continue
        n += 1
        rows.append({
            "date": date, "description": normalize_desc(rec.get("desc") or rec.get("description")),
            "amount": round(float(amount), 2), "currency": rec.get("currency"),
            "memo": rec.get("memo"), "balance": parse_amount(rec.get("balance")),
            "source_row": lidx,
        })
    return rows


# ---------------------------------------------------------------- main

def detect_format(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".ofx", ".qfx", ".qbo"):
        return "ofx"
    if ext == ".json":
        return "json"
    if ext in (".csv", ".tsv", ".txt"):
        return "csv"
    return "csv"


def load_existing_ids(ledger_path):
    ids = set()
    if os.path.exists(ledger_path):
        with open(ledger_path, "r", encoding="utf-8", newline="") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                if row.get("txn_id"):
                    ids.add(row["txn_id"])
    return ids


def main(argv=None):
    ap = argparse.ArgumentParser(description="Bookkeeping Rescue - statement ingestion")
    ap.add_argument("files", nargs="+", help="statement files to ingest")
    ap.add_argument("--out", required=True, help="books/ output directory")
    ap.add_argument("--account", default="Unspecified", help="account name for these rows")
    ap.add_argument("--year", type=int, default=None, help="filter to this year")
    ap.add_argument("--date-order", choices=["auto", "us", "eu"], default="auto")
    ap.add_argument("--map", dest="map_file", default=None,
                    help="mapping.json for text extracted from PDF statements")
    args = ap.parse_args(argv)

    out_dir = os.path.abspath(args.out)
    os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)
    ledger_path = os.path.join(out_dir, "ledger.csv")

    map_spec = None
    if args.map_file:
        with open(args.map_file, "r", encoding="utf-8") as fh:
            map_spec = json.load(fh)

    seen_ids = load_existing_ids(ledger_path)
    new_rows, report = [], []

    for path in args.files:
        fmt = detect_format(path)
        if map_spec is not None and fmt == "csv" and os.path.splitext(path)[1].lower() == ".txt":
            fmt = "mapped"
        try:
            if fmt == "ofx":
                rows = parse_ofx_file(path)
            elif fmt == "json":
                rows = parse_json_file(path, args.date_order)
            elif fmt == "mapped":
                rows = parse_mapped_text(path, map_spec, args.date_order)
            else:
                rows = parse_csv_file(path, args.account, args.date_order)
        except Exception as exc:  # noqa: BLE001 - report and continue
            report.append("| {} | ERROR | - | - | {} |".format(os.path.basename(path), exc))
            continue

        added = dupes = skipped_year = 0
        for r in rows:
            if args.year and not r["date"].startswith(str(args.year)):
                skipped_year += 1
                continue
            tid = fingerprint(r["date"], r["description"], r["amount"], args.account)
            if tid in seen_ids:
                dupes += 1
                continue
            seen_ids.add(tid)
            new_rows.append({
                "txn_id": tid,
                "date": r["date"],
                "description": r["description"],
                "amount": "{:.2f}".format(r["amount"]),
                "currency": r.get("currency") or "",
                "account": args.account,
                "memo": r.get("memo") or "",
                "source_file": os.path.basename(path),
                "source_row": r["source_row"],
                "category": "",
                "status": "unreviewed",
                "confidence": "",
                "notes": "",
            })
            added += 1
        report.append("| {} | {} | {} | {} | {} |".format(
            os.path.basename(path), fmt, added, dupes, skipped_year))

    write_header = not os.path.exists(ledger_path) or os.path.getsize(ledger_path) == 0
    if new_rows:
        with open(ledger_path, "a", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=LEDGER_COLUMNS)
            if write_header:
                writer.writeheader()
            for row in new_rows:
                writer.writerow(row)

    total = 0
    if os.path.exists(ledger_path):
        with open(ledger_path, "r", encoding="utf-8", newline="") as fh:
            total = max(0, sum(1 for _ in fh) - 1)

    lines = [
        "# Ingest Report", "",
        "Account: **{}**  |  Rows added: **{}**  |  Ledger total rows: **{}**".format(
            args.account, len(new_rows), total),
        "", "| File | Format | Added | Duplicates skipped | Out-of-year skipped |",
        "|---|---|---|---|---|",
    ] + report + [
        "",
        "Every row keeps `source_file` and `source_row` for traceability.",
        "Next: `python scripts/categorize.py --ledger books/ledger.csv --rules books/rules.csv --out books/`",
    ]
    report_path = os.path.join(out_dir, "out", "ingest-report.md")
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    print("Added {} rows to {}".format(len(new_rows), ledger_path))
    print("Report: {}".format(report_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
