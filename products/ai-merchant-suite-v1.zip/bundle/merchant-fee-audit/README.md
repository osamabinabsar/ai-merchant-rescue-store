# Merchant Fee Audit

Audit your credit card processing statement and find the money you are silently
overpaying. Contingency auditors charge 25-50% of recovered savings for this
analysis. This skill does it deterministically and you keep 100%.

## What it does

1. **Ingest** merchant account statement lines (CSV, TSV, JSON, or simple text
   exports) into a normalized register. Weird ISO fee names map to canonical keys.
2. **Audit** your true effective rate month by month, break fees down by
   classification (NORMAL / NEGOTIABLE / JUNK / ESCALATE), compare against
   benchmark rates for your card mix, and estimate the annualized savings as a
   labeled range.
3. **Renegotiate** with a pre-written letter that carries your actual numbers:
   effective rate, the junk fees to remove, the markup ask.

## Why it is different

- Deterministic stdlib Python does the math. Every figure traces to a statement line.
- Junk fees are named: PCI "compliance" fees, statement fees, annual fees,
  monthly minimum shortfalls.
- Benchmark table carries a drift guard, so stale rates are flagged instead of quoted.
- Your statement data never leaves the machine.

## Requirements

- Python 3.9+ (stdlib only, no dependencies, no network access)

## Verify it before trusting it

```bash
python scripts/selfcheck.py
```

Runs the full pipeline against bundled sample statements and prints a
pass/fail list.

## Contents

```
SKILL.md                        skill definition for Claude Code / Codex / compatible agents
scripts/ingest_statement.py     statement normalization + fee key mapping
scripts/fee_audit.py            effective rate, junk fees, savings estimate
scripts/negotiate_report.py     renegotiation letter with your numbers
scripts/selfcheck.py            33-check self test
references/fee-dictionary.md    fee types and junk classifications
references/benchmarks.md        benchmark rates (drift-guarded, labeled placeholders)
references/negotiation-playbook.md  how to run the renegotiation
templates/                      statement schema, renegotiation letter
tests/fixtures/                 sample statements
```

Not financial or legal advice. It analyzes numbers and drafts a request;
contract review and early-termination questions need a human attorney.
