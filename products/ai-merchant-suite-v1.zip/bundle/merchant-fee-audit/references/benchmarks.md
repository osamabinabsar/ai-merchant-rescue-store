# Benchmark Rates (drift guard)

Version: 2026-10. **All values below are labeled placeholders.** Interchange and
assessment rates are set by the card networks and change twice a year (usually
April and October). `fee_audit.py` prints a drift warning when this file is older
than the check date by more than 12 months. Verify against current published
network interchange before quoting a target in the renegotiation letter.

## Blended effective-rate targets (all-in fees / card volume)

| Business profile | Healthy target | Above this, negotiate |
|---|---|---|
| Card-present, retail/restaurant | 2.0% - 2.4% | > 2.6% |
| Card-not-present, e-commerce | 2.5% - 2.9% | > 3.1% |
| B2B / keyed-in / professional services | 2.6% - 3.0% | > 3.2% |
| High-risk or subscription billing | 3.0% - 3.8% | > 4.2% |

These are **effective rate** targets: total monthly fees divided by total
monthly card volume, including interchange, assessments, and processor markup.

## Component benchmarks (placeholders, US market)

| Component | Typical healthy level |
|---|---|
| Interchange (blended) | ~1.5% - 2.2% depending on card mix (rewards and business cards cost more) |
| Network assessments | ~0.13% - 0.16% |
| Processor markup, interchange-plus | 0.10% - 0.30% + $0.05-$0.15 per transaction |
| Processor markup, tiered | Hidden; effective gap over interchange-plus is often 0.4%-1.0% |
| PCI compliance fee | $0 is the correct answer; $99-$199/yr is common but removable |
| Statement fee | $0 is the correct answer; $5-$15/mo is common |
| Monthly minimum | $25/mo typical; waivable on request |
| Batch/closeout fee | $0.10-$0.30 per batch |
| AVS fee | $0.01-$0.10 per use |

## How fee_audit.py uses this file

- Weighted benchmark: each volume line's card type maps to a target range; the
  audit uses the **midpoint of the healthy range** as `benchmark_rate`.
- Savings estimate: `actual annual fees - (benchmark_rate x annual volume)`.
  Low estimate = 50% of that gap (renegotiations rarely capture 100%);
  high estimate = full gap plus fully removable junk fees.
- Everything is reported as an estimate range, never a promise.

## Why the drift guard exists

A skill that quotes 2024 interchange targets in 2027 loses the user's trust in
the first meeting with their processor. The version stamp above is the contract.
