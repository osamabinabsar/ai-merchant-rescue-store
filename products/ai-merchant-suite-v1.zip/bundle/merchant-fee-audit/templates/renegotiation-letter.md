# Renegotiation Letter Template

Subject: Merchant account rate review - account ending {{account_tail}}

Hello {{contact_name}},

I've reviewed our card processing statements for {{period_covered}} and I'd like
to discuss adjusting our terms to better match current market rates for a
business of our profile.

Our numbers over that period:

- Total card volume: {{annual_volume}}
- Total processing fees: {{annual_fees}}
- Effective rate: {{effective_rate}} ({{benchmark_rate}} is typical for our profile)
- Fees I'd like removed: {{junk_fee_list}}
- Annualized gap versus market: {{savings_estimate}}

Concretely, I'm asking for:

1. Removal of the {{junk_fee_list}} fees.
2. A discount rate of {{target_markup}} basis points above interchange, with
   per-transaction pricing of {{target_per_txn}} or better.
3. Waiver or reduction of the monthly minimum.

I've been comparing interchange-plus options in the {{benchmark_rate}} effective
range and would prefer to continue working with you. Could you confirm what you
can do, in writing, by {{reply_by_date}}?

Thank you,

{{merchant_name}}
{{merchant_contact}}

---

Assembly rules (for the agent, delete before sending):

- Every `{{...}}` must come from `out/audit-report.md` values. If a value is
  unknown, write "not available" and tell the user. Never estimate into a letter.
- `{{savings_estimate}}` uses the audit's range, e.g. "$2,100 - $4,200 per year".
- Keep the tone flat and factual. The numbers do the arguing.
