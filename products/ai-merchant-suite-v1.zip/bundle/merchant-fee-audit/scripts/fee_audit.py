#!/usr/bin/env python3
"""Audit a normalized merchant statement: effective rate, junk fees, savings.

Deterministic. Writes audit-report.md and audit-data.json (machine-readable,
consumed by negotiate_report.py).
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from datetime import date
from pathlib import Path

# Classification mirrors references/fee-dictionary.md.
CLASSIFICATION = {
    "interchange": "NORMAL",
    "scheme_fee": "NORMAL",
    "chargeback_fee": "NORMAL",
    "processor_markup": "NEGOTIABLE",
    "monthly_fee": "NEGOTIABLE",
    "batch_fee": "NEGOTIABLE",
    "avs_fee": "NEGOTIABLE",
    "gateway_fee": "NEGOTIABLE",
    "pci_scan": "NEGOTIABLE",
    "monthly_minimum": "NEGOTIABLE",
    "pci_fee": "JUNK",
    "statement_fee": "JUNK",
    "annual_fee": "JUNK",
    "early_termination": "ESCALATE",
    "other": "REVIEW",
}

# Weighted benchmark midpoints (% of volume), from references/benchmarks.md.
BENCHMARKS = {
    ("no", "credit"): 2.7, ("no", "rewards"): 2.7, ("no", "business"): 2.8,
    ("yes", "credit"): 2.2, ("yes", "rewards"): 2.2, ("yes", "debit"): 1.6,
}
BENCHMARK_DEFAULT = 2.5  # unknown mix


def drift_warning(ref_path: Path, today: date) -> str | None:
    if not ref_path.exists():
        return None
    m = re.search(r"Version:\s*(\d{4})-(\d{2})", ref_path.read_text(encoding="utf-8"))
    if not m:
        return None
    version = date(int(m.group(1)), int(m.group(2)), 1)
    months = (today.year - version.year) * 12 + (today.month - version.month)
    if months > 12:
        return (f"DRIFT WARNING: {ref_path.name} is {months} months old. "
                "Verify benchmark rates before quoting them to a processor.")
    return None


def load_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def benchmark_for(card_type: str, present: str) -> float:
    return BENCHMARKS.get((present, card_type), BENCHMARKS.get((present, "credit"), BENCHMARK_DEFAULT))


def audit(rows: list[dict]) -> dict:
    months: dict[str, dict] = {}
    for r in rows:
        m = r.get("month", "")
        slot = months.setdefault(m, {"volume": 0.0, "fees": 0.0})
        amount = float(r.get("amount") or 0)
        if r.get("line_type") == "volume":
            slot["volume"] += amount
        else:
            slot["fees"] += amount

    total_volume = sum(s["volume"] for s in months.values())
    total_fees = sum(s["fees"] for s in months.values())
    n_months = len(months) or 1
    effective_rate = 100 * total_fees / total_volume if total_volume else 0.0

    bench_fees = 0.0
    for r in rows:
        if r.get("line_type") == "volume":
            amount = float(r.get("amount") or 0)
            bench_fees += amount * benchmark_for(r.get("card_type", ""), r.get("present", "")) / 100
    benchmark_rate = 100 * bench_fees / total_volume if total_volume else BENCHMARK_DEFAULT

    fee_lines = [r for r in rows if r.get("line_type") == "fee"]
    fee_totals: dict[str, dict] = {}
    for r in fee_lines:
        key = r.get("fee_key", "other")
        slot = fee_totals.setdefault(key, {"total": 0.0, "count": 0, "desc": r.get("description", "")})
        slot["total"] += float(r.get("amount") or 0)
        slot["count"] += 1

    junk_keys = [k for k, cls in CLASSIFICATION.items() if cls == "JUNK"]
    junk_total = sum(fee_totals[k]["total"] for k in junk_keys if k in fee_totals)

    annual_factor = 12 / n_months
    gap_annual = max(0.0, (total_fees - bench_fees)) * annual_factor
    junk_annual = junk_total * annual_factor
    savings_high = gap_annual + junk_annual
    savings_low = savings_high * 0.5

    monthly_minimum_case = ""
    if "monthly_minimum" in fee_totals:
        markup = fee_totals.get("processor_markup", {}).get("total", 0.0)
        monthly_minimum_case = (
            "The shortfall ties to fee level, so negotiate the markup and ask for the minimum waived."
            if markup > 0 else
            "Low volume drives the shortfall; ask for the minimum reduced or waived.")

    per_month = [
        {"month": m, "volume": round(s["volume"], 2), "fees": round(s["fees"], 2),
         "effective_rate": round(100 * s["fees"] / s["volume"], 2) if s["volume"] else 0.0}
        for m, s in sorted(months.items())
    ]

    return {
        "months": per_month,
        "n_months": n_months,
        "total_volume": round(total_volume, 2),
        "total_fees": round(total_fees, 2),
        "annual_volume": round(total_volume * annual_factor, 2),
        "annual_fees": round(total_fees * annual_factor, 2),
        "effective_rate": round(effective_rate, 2),
        "benchmark_rate": round(benchmark_rate, 2),
        "fee_totals": {k: {"total": round(v["total"], 2), "count": v["count"], "desc": v["desc"],
                           "classification": CLASSIFICATION.get(k, "REVIEW")}
                       for k, v in fee_totals.items()},
        "junk_total": round(junk_total, 2),
        "gap_annual": round(gap_annual, 2),
        "savings_low": round(savings_low, 2),
        "savings_high": round(savings_high, 2),
        "monthly_minimum_case": monthly_minimum_case,
    }


def write_report(out_dir: Path, data: dict, warnings: list[str]) -> None:
    lines = [
        "# Merchant Fee Audit", "",
        f"Effective rate: **{data['effective_rate']}%** "
        f"(weighted benchmark for this card mix: {data['benchmark_rate']}%)", "",
        f"Annualized volume: {data['annual_volume']} | Annualized fees: {data['annual_fees']}", "",
        "## Savings estimate (a range, not a promise)",
        "",
        f"- Low: **{data['savings_low']}** per year (50% of the gap closed)",
        f"- High: **{data['savings_high']}** per year (full gap plus removable junk fees)",
        "",
        "## Monthly breakdown", "",
        "| Month | Volume | Fees | Effective rate |",
        "|---|---|---|---|",
    ]
    for m in data["months"]:
        lines.append(f"| {m['month']} | {m['volume']} | {m['fees']} | {m['effective_rate']}% |")
    lines += ["", "## Fee lines", "", "| Fee key | Description | Total | Times billed | Classification |", "|---|---|---|---|---|"]
    for key, v in sorted(data["fee_totals"].items(), key=lambda kv: -kv[1]["total"]):
        lines.append(f"| {key} | {v['desc']} | {v['total']} | {v['count']} | {v['classification']} |")
    if data["monthly_minimum_case"]:
        lines += ["", f"Monthly minimum: {data['monthly_minimum_case']}"]
    if warnings:
        lines += [""] + [f"> {w}" for w in warnings]
    (out_dir / "audit-report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (out_dir / "audit-data.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--statement", default="merchant-audit/statement.csv")
    ap.add_argument("--out", default="merchant-audit/out")
    args = ap.parse_args()

    stmt_path = Path(args.statement)
    if not stmt_path.exists():
        print(f"ERROR: statement register not found: {stmt_path}. Run ingest_statement.py first.", file=sys.stderr)
        return 1

    rows = load_csv(stmt_path)
    data = audit(rows)
    warnings = [w for w in [drift_warning(Path(__file__).resolve().parent.parent / "references" / "benchmarks.md", date.today())] if w]
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_report(out_dir, data, warnings)

    print(f"Effective rate: {data['effective_rate']}% vs benchmark {data['benchmark_rate']}%. "
          f"Estimated savings {data['savings_low']}-{data['savings_high']} per year. "
          f"Report: {out_dir}/audit-report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
