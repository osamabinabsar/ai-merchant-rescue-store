# Fee Dictionary

Version: 2026-10. Keep in sync with the ALIASES and CLASSIFICATION tables in
`scripts/ingest_statement.py` and `scripts/fee_audit.py`.

## Pricing models (identify first)

| Model | How it shows on the statement | Renegotiation lever |
|---|---|---|
| Interchange-plus / pass-through | Interchange fees listed per card type, plus a separate markup ("discount rate", "merchant markup") | Shrink the markup; junk fees still attackable |
| Tiered (qualified / mid / non-qualified) | "Qualified rate", "Mid-qualified", "Non-qualified" buckets | Escape the bucketing; demand interchange-plus quotes |
| Flat / bundled (Stripe, Square, PayPal) | One percentage per transaction type, no interchange lines | Usually not negotiable below list; volume tiers and interchange-plus alternatives are the lever |
| Subscription / membership pricing (e.g., Interchange+X cents + monthly fee) | Tiny markup + monthly platform fee | Compare membership fee against effective rate |

## Fee lines

| Canonical key | Typical descriptions | Classification |
|---|---|---|
| interchange | "DISC", "INT", "INTERCHANGE", "QB", "VS INT" | NORMAL (cost of the network, but benchmarkable) |
| scheme_fee | "ASSESS", "NABU", "VISA ASSESS", "MC SCHEME" | NORMAL (network assessments, small) |
| processor_markup | "DISCOUNT RATE", "MARKUP", "MERCH DISC", "MDR" | NEGOTIABLE (the processor's cut) |
| pci_fee | "PCI NON-COMP", "PCI COMPLIANCE", "PCI NONCOMPLIANCE FEE" | JUNK (removable: often you comply and they charge anyway) |
| statement_fee | "STMT FEE", "STATEMENT", "REPORTING" | JUNK (removable: you are paying to be billed) |
| monthly_fee | "SVC FEE", "MONTHLY FEE", "ACCOUNT FEE" | NEGOTIABLE (often waivable) |
| annual_fee | "ANNUAL FEE", "MEMBERSHIP" | JUNK (renegotiable) |
| batch_fee | "BATCH FEE", "CLOSEOUT" | NEGOTIABLE (small per-batch junk) |
| avs_fee | "AVS", "ADDR VERIF" | NEGOTIABLE (should be cents at most) |
| monthly_minimum | "MINIMUM", "SHORTFALL", "MIN FEE" | DEPENDS (see below) |
| gateway_fee | "GATEWAY", "AUTH GATEWAY" | NEGOTIABLE (compare against actual auth counts) |
| chargeback_fee | "CHGBCK", "CBK FEE", "DISPUTE FEE" | NORMAL-ish (watch count; pair with dispute defense tooling) |
| pci_scan | "SCAN FEE", "SECURITY SCAN" | NEGOTIABLE |
| early_termination | "ETF", "TERMINATION" | ESCALATE (contract term; get a human to read the contract) |
| other | anything unmatched | REVIEW |

## Monthly minimum logic

A "monthly minimum" fee is the shortfall between the processor's minimum monthly
fee (say $25) and the fees you generated that month.
- If the shortfall is caused by **junk fees being excluded from the minimum
  calculation** or by a **high markup**, it is attackable via rate negotiation.
- If the shortfall is caused by genuinely low volume, the minimum itself is the
  target: ask for it waived or reduced.
- The audit report must state which case applies (it uses the fee composition).

## Upgrade notes

Processor fee names are deliberately weird and vary by ISO. When a description
does not match any alias, the line goes to `out/review-queue.csv` with its raw
text and the three closest keys by keyword overlap. The human's answer extends
the alias table once; that decision is never re-asked.
