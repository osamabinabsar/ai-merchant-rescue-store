#!/usr/bin/env python3
"""Score dispute evidence against card-network reason-code checklists.

Deterministic. Weights mirror references/reason-codes.md (keep in sync).
Outputs evidence-scorecard.md and missing.csv per dispute.
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

# key -> (item description, weight)
CHECKLISTS = {
    "GENERIC": {
        "receipt": ("Itemized receipt or order confirmation", 2),
        "proof_of_service": ("Evidence the product or service was delivered", 2),
        "customer_communication": ("Any customer message about the order", 1),
        "terms": ("Terms of service or refund policy", 1),
    },
    "VISA-10.4": {
        "avs_match": ("AVS match result from the processor", 2),
        "cvv_match": ("CVV verification result", 2),
        "ip_device": ("IP address and device fingerprint", 2),
        "account_history": ("Prior undisputed purchases from the same account", 2),
        "usage_after": ("Login or usage activity after the purchase date", 2),
        "delivery": ("Delivery to the billing or verified address", 1),
        "customer_communication": ("Customer referenced the purchase in messages", 1),
    },
    "VISA-13.1": {
        "delivery": ("Tracking with delivery confirmation", 3),
        "proof_of_service": ("Download/access logs or service activation", 2),
        "receipt": ("Order confirmation with delivery terms", 1),
        "customer_communication": ("Messages showing the customer knew it shipped", 1),
    },
    "VISA-13.3": {
        "product_description": ("Pre-purchase description, photos or spec sheet", 2),
        "terms": ("Return/refund policy shown at checkout", 2),
        "customer_communication": ("Messages where the customer describes the issue", 2),
        "proof_of_service": ("Evidence the product matches the description", 2),
        "refund_attempt": ("Record of a refund offered, refused or completed", 1),
    },
    "VISA-13.7": {
        "terms": ("Cancellation policy agreed to at signup", 3),
        "usage_after": ("Usage after the claimed cancellation date", 2),
        "customer_communication": ("Messages showing the customer continued", 2),
        "receipt": ("Billing terms the customer accepted", 1),
    },
    "VISA-13.2": {
        "transaction_records": ("Both transaction records showing distinct orders", 3),
        "receipt": ("Receipts for each charge", 2),
        "customer_communication": ("Messages showing two separate purchases", 1),
    },
}
CHECKLISTS["MASTERCARD-4837"] = CHECKLISTS["VISA-10.4"]
CHECKLISTS["MASTERCARD-4853"] = CHECKLISTS["VISA-13.1"]

MIN_VIABLE_SCORE = 60
STRONG_WEIGHT = 3


def load_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as fh:
        return list(csv.DictReader(fh))


def is_weak(item: dict) -> bool:
    notes = (item.get("notes") or "").strip()
    etype = (item.get("evidence_type") or "").strip()
    if len(notes) < 8:
        return True
    if etype == "delivery" and not any(c.isdigit() for c in notes):
        return True
    if etype == "customer_communication" and '"' not in notes and "'" not in notes:
        return True
    return False


def score_dispute(case: dict, evidence_rows: list[dict]) -> dict:
    code = case.get("reason_code", "GENERIC")
    checklist = CHECKLISTS.get(code, CHECKLISTS["GENERIC"])
    present = {r["evidence_type"]: r for r in evidence_rows if r.get("dispute_id") == case.get("dispute_id")}
    total = sum(w for _, w in checklist.values())
    got = 0.0
    items = []
    for key, (desc, weight) in checklist.items():
        item = present.get(key)
        if item is None:
            items.append({"key": key, "desc": desc, "weight": weight, "status": "MISSING"})
        elif is_weak(item):
            got += weight * 0.5
            items.append({"key": key, "desc": desc, "weight": weight, "status": "WEAK"})
        else:
            got += weight
            items.append({"key": key, "desc": desc, "weight": weight, "status": "PRESENT"})
    extra = [r["evidence_type"] for r in evidence_rows
             if r.get("dispute_id") == case.get("dispute_id") and r["evidence_type"] not in checklist]
    score = round(100 * got / total) if total else 0
    blocking = [i for i in items if i["status"] == "MISSING" and i["weight"] >= STRONG_WEIGHT]
    viable = score >= MIN_VIABLE_SCORE and not blocking
    return {"case": case, "items": items, "score": score, "viable": viable,
            "blocking": blocking, "extra": extra}


def write_outputs(out_dir: Path, results: list[dict]) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    lines = ["# Evidence Scorecard", ""]
    missing_rows = []
    for res in results:
        c = res["case"]
        lines.append(f"## Dispute {c.get('dispute_id')} ({c.get('reason_code')}) - {c.get('amount')} {c.get('currency')}")
        lines.append("")
        lines.append(f"- Score: **{res['score']}/100**  |  Minimum viable packet: {MIN_VIABLE_SCORE} with no missing high-weight item")
        verdict = "READY TO ASSEMBLE" if res["viable"] else "GATHER MORE EVIDENCE FIRST"
        lines.append(f"- Verdict: **{verdict}**")
        if c.get("respond_by"):
            note = " (estimated)" if c.get("respond_by_estimated") == "yes" else ""
            lines.append(f"- Respond by: **{c['respond_by']}**{note}")
        lines.append("")
        lines.append("| Status | Item | Weight |")
        lines.append("|---|---|---|")
        for i in res["items"]:
            lines.append(f"| {i['status']} | {i['desc']} | {i['weight']} |")
            if i["status"] in ("MISSING", "WEAK"):
                missing_rows.append({"dispute_id": c.get("dispute_id"), "status": i["status"],
                                     "evidence_type": i["key"], "item": i["desc"], "weight": i["weight"]})
        if res["extra"]:
            lines.append("")
            lines.append(f"(Uncounted extra evidence: {', '.join(res['extra'])}. Map to a checklist key to score it.)")
        lines.append("")
    (out_dir / "evidence-scorecard.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    with (out_dir / "missing.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=["dispute_id", "status", "evidence_type", "item", "weight"])
        writer.writeheader()
        writer.writerows(missing_rows)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--cases", default="cases/cases.csv")
    ap.add_argument("--evidence", default="cases/evidence-index.csv")
    ap.add_argument("--out", default="cases/out")
    args = ap.parse_args()

    cases_path, evidence_path = Path(args.cases), Path(args.evidence)
    if not cases_path.exists():
        print(f"ERROR: cases register not found: {cases_path}", file=sys.stderr)
        return 1
    if not evidence_path.exists():
        print(f"ERROR: evidence index not found: {evidence_path}. "
              "Create it from templates/evidence-index.example.csv.md first.", file=sys.stderr)
        return 1

    cases = load_csv(cases_path)
    evidence = load_csv(evidence_path)
    results = [score_dispute(c, evidence) for c in cases]
    write_outputs(Path(args.out), results)
    for res in results:
        state = "READY" if res["viable"] else "NEEDS EVIDENCE"
        print(f"{res['case'].get('dispute_id')}: {res['score']}/100 [{state}]")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
