# Deduction Rules & Substantiation

General information for organizing records — **not tax advice**. The skill's
job is to sort and flag; a CPA/EA makes the filing calls.

## The three questions for every expense

1. **Ordinary & necessary?** Common and accepted in the trade, and helpful/appropriate.
2. **Business purpose?** Who, what, why — one line in `notes` beats a receipt pile.
3. **Substantiated?** Amount, date, payee, purpose. Documented at the time, not reconstructed in April.

If any answer is "no" or "unknown", the row stays `Review` and lands in the CPA question list.

## High-value categories people miss

- **Home office** (Form 8829): regular and exclusive use; simplified method has a fixed per-sq-ft cap (see rate-card), actual method needs utility/rent allocation.
- **Vehicle**: mileage log OR actual expenses; commuting is never deductible; the log is the substantiation.
- **Phone/internet**: business-use percentage only; keep a defensible basis.
- **Startup costs**: up to a statutory first-year limit, remainder amortized (confirm current-year figures with CPA).
- **Software, AI tools, subscriptions**: fully deductible if ordinary and necessary.
- **Professional development**: courses/books/conferences in your current trade (not preparing for a new career).
- **Payment processing fees**: fully deductible; easy to forget because they're netted out of payouts — ingest the gross payout AND the fee rows when the platform gives both.

## Substantiation standards (what to keep)

| Expense type | Keep |
|---|---|
| Under $75 (non-travel) | Ledger row usually enough (IRS Pub. 463 practice) |
| $75+ | Receipt/invoice |
| Travel, lodging, vehicle | Receipts + contemporaneous log/purpose |
| Meals | Amount, date, place, business purpose, who attended |
| Split personal/business | Allocation basis in `notes` |

## Red flags (always flag, never resolve alone)

- Round-number ATM cash withdrawals with no receipt trail
- Repeated "miscellaneous" or "cash" categories
- Loan interest vs. personal interest confusion
- Revenue recorded net of platform fees (gross-up needed)
- Any question phrased "can I deduct..." → categorize, flag, refer to CPA

## Deductibility quick matrix

| Item | Typical treatment | Always verify |
|---|---|---|
| Client meals | 50% | Business purpose documented |
| Team meals (recreational) | Sometimes 100% | Conditions vary |
| Fines/penalties (parking tickets) | Never deductible | — |
| Gifts (business) | Deductible, per-gift cap | Current-year cap |
| Charitable donations | Not a Schedule C expense | Schedule A / entity rules |
| Health insurance | Not Schedule C | Schedule 1 / entity rules |
| Life insurance (key person) | Generally not | Entity structure |
| Clothing (uniforms) | Only if required & not everyday wear | — |
