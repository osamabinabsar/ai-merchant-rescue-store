# Renegotiation Playbook

General patterns from published merchant-services guidance. Not legal or
financial advice; contract terms vary and early-termination clauses need a human
attorney.

## The sequence that works

1. **Audit first, talk second.** Never open the conversation without the numbers.
   The audit report is the script.
2. **Ask for three things in one message:**
   - Remove the junk fees (PCI, statement, annual). These are usually granted
     without a fight because they are nearly pure margin.
   - Reduce the markup to the benchmark target (interchange-plus quote if tiered).
   - Waive or lower the monthly minimum.
3. **Name the alternative without threatening.** "I've been comparing
   interchange-plus quotes in the 2.4% effective range" does more than any
   ultimatum. One factual sentence.
4. **Get the new terms in writing before agreeing.** Verbal promises at the ISO
   vanish; email confirmation is the record.
5. **Re-audit 30 days later.** Verify the change landed on the next statement.
   Backsliding is common (new "program" fees appear). The skill's Step 4 exists
   for this.

## Tactics by pricing model

### Interchange-plus
The markup is the whole negotiation. Ask for the markup in basis points AND
cents per transaction (processors hide one while lowering the other).

### Tiered
The buckets are the product; merchants lose because qualified rates are
advertised and everything downgrades silently. Two levers:
- Demand an interchange-plus quote (in writing, all-in).
- Ask which of your card types are downgrading and why (rewards and business
  cards almost always do; the statement breakdown shows the damage).

### Flat rate (Stripe/Square/PayPal style)
List pricing is rarely negotiable below published volume tiers. The real
questions: (a) does your volume qualify for a custom rate (usually needs
$80k-$250k/mo), (b) is an interchange-plus merchant account cheaper at your
volume (the audit report answers this).

## Phrases that land

- "Here's my effective rate for the last 6 months: X%. The market for my profile
  is about Y%. I'd like to close that gap."
- "Please remove the PCI compliance fee; I'm compliant and the scan report is
  attached."
- "Can you confirm in writing that my new discount rate is Z basis points with
  no statement or annual fees?"

## Phrases that don't

- "I'm leaving." (before you have a competing quote in hand)
- "My friend pays less." (unverifiable claims weaken the ask)
- Anything emotional. The numbers are the leverage.

## What to check before signing anything new

- Early-termination fee and its window
- Whether the "new rate" is an introductory rate with an expiration
- Whether junk fees are actually removed or renamed
- Whether the term auto-renews (and for how long)
- Whether the equipment lease is separate (leases are usually the worst part)
