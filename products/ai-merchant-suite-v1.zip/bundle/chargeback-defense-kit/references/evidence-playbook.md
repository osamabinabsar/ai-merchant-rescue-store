# Evidence Playbook: What Actually Wins

Version 2026-10. General patterns from published network representment data and
processor guidance. Not legal advice.

## Argument order that works

Arbitrators scan fast. Lead with the single strongest exhibit, then the timeline,
then the rest. The cover letter template already structures this; when choosing
the lead exhibit, use this priority:

1. **Digital usage after purchase** (logins, API calls, downloads). Beats
   every other exhibit in fraud-coded disputes because it is nearly impossible
   to fake from the cardholder's side.
2. **Delivery confirmation with signature or GPS scan.** Strongest for
   not-received claims.
3. **Customer's own words.** A message where the customer references the
   product, the account, or the delivery. One quote often ends the case.
4. **AVS/CVV match + IP/device data.** Supporting evidence for fraud claims,
   rarely decisive alone.
5. **Terms and receipts.** The backbone of cancel/return disputes.

## By dispute category

### "I never authorized this" (fraud-coded, incl. friendly fraud)

- Prove the buyer is the user, not the cardholder. Account history with prior
  undisputed orders is powerful: "same account, same device, same address,
  6 previous orders" is a pattern no fraudster builds.
- Usage after the disputed date is the killer exhibit. Login logs, API key use,
  saved-work activity, download of the purchased file.
- Delivery to the billing address or a previously verified address.
- Keep the tone factual. Never accuse; let the records contradict the claim.

### "Product never arrived"

- Carrier tracking with a delivery scan (not just "shipped").
- If the carrier scan is thin (marked delivered, no signature), add the
  follow-up trail: your delivery-check email and the customer's reply, or
  absence of a non-delivery complaint within your claim window.
- Digital goods: download or access logs with timestamps and IP.

### "Not as described / defective"

- Pre-purchase description screenshots, specs, photos, version notes.
- The customer's own description of the problem, compared against the product
  record. If they claim "empty box" but used the software for 3 weeks, say so
  with the log attached.
- Your return/refund policy as shown at checkout (not as it exists on some page).
- A refund you offered that the customer ignored or refused is persuasive.

### "Canceled subscription / service"

- The cancellation terms the customer agreed to (with date of agreement).
- Usage after the claimed cancellation date. Even one login weakens their claim.
- Any message where the customer acknowledged continuing.
- A cancellation you processed, if it happened after the billing date: show the
  billing date and the cancellation date honestly. Partial honesty (agreeing the
  cancel happened, showing it was after the cycle) wins more than overclaiming.

### "Charged twice / paid by other means"

- Both transaction records, order IDs, timestamps.
- Evidence the two orders were separate purchases (two order confirmations,
  two shipments, two carts).
- If it genuinely is a duplicate: do not fight it. Refund and log the loss.
  Fighting an obvious duplicate burns merchant-account credibility.

## Upgrading weak items

| Weak version | Upgrade |
|---|---|
| Delivery note, no tracking | Carrier API export with the delivery scan |
| Screenshot of an email | The full email with headers |
| "Customer used the product" | Timestamped usage log export, not a summary |
| Refund policy link | Screenshot of the policy as rendered at checkout |
| Verbal phone call | Written recap email sent after the call |

## Packet presentation rules

- Number every exhibit (Exhibit 1, Exhibit 2...).
- One paragraph per claim point, each ending with "(Exhibit N)".
- Timeline table before the argument. Dates settle more disputes than adjectives.
- Keep the whole packet under about 10 pages of narrative plus exhibits.
