#!/usr/bin/env python3
"""Bookkeeping Rescue - deterministic reconciliation.

Validates the ledger before any report is trusted:
  * parse sanity (dates, numeric amounts)
  * duplicate transaction fingerprints
  * suspected internal transfers (opposite signs, similar amounts, <=3 days apart)
  * date-coverage gaps vs. the period actually imported
  * sign sanity (a business account with zero inflows is suspicious)
  * closing-balance agreement when the user provides statement balances
  * unreviewed-row count

Usage:
    python reconcile.py --ledger books/ledger.csv --out books/ \
        [--closing "Chase Checking=2026-03-31:4821.12"] [--closing ...]

Exit code: 0 = clean (PASS/WARN only), 1 = at least one FAIL.
"""
import argparse
import csv
import os
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta


def parse_date(s):
    try:
        return datetime.strptime(s.strip(), "%Y-%m-%d").date()
    except (ValueError, AttributeError):
        return None


def main(argv=None):
    ap = argparse.ArgumentParser(description="Bookkeeping Rescue - reconciliation")
    ap.add_argument("--ledger", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--closing", action="append", default=[],
                    help='account=YYYY-MM-DD:balance, repeatable')
    args = ap.parse_args(argv)

    with open(args.ledger, "r", encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))

    findings = []  # (level, check, message)

    # 1. Parse sanity
    bad = [r for r in rows if parse_date(r.get("date")) is None]
    for r in bad:
        findings.append(("FAIL", "parse", "Unparseable date in row {} ({})".format(
            r.get("source_row"), r.get("description", "")[:40])))
    bad_amt = [r for r in rows if _num(r.get("amount")) is None]
    for r in bad_amt:
        findings.append(("FAIL", "parse", "Unparseable amount in row {} ({})".format(
            r.get("source_row"), r.get("description", "")[:40])))

    # 2. Duplicates (same fingerprint appearing more than once)
    by_id = defaultdict(list)
    for r in rows:
        by_id[r.get("txn_id", "")].append(r)
    for tid, group in by_id.items():
        if tid and len(group) > 1:
            findings.append(("FAIL", "duplicates",
                             "Duplicate transaction fingerprint {} x{}: {} {}".format(
                                 tid, len(group), group[0].get("date"),
                                 group[0].get("description", "")[:40])))

    # 3. Suspected internal transfers
    TRANSFER_RE = re.compile(
        r"\b(transfer|zelle|venmo|credit card payment|payment thank you|atm withdrawal)\b", re.I)
    inflows = [r for r in rows if _num(r.get("amount", 0)) > 0]
    outflows = [r for r in rows if _num(r.get("amount", 0)) < 0]
    used = set()
    matched_out = set()
    for o in outflows:
        od = parse_date(o.get("date"))
        oamt = abs(_num(o.get("amount", 0)) or 0)
        if not od or oamt == 0:
            continue
        for i in inflows:
            if i.get("txn_id") in used or i.get("account") == o.get("account"):
                continue
            idt = parse_date(i.get("date"))
            iamt = _num(i.get("amount", 0)) or 0
            if not idt:
                continue
            if abs(iamt - oamt) <= 0.02 and abs((idt - od).days) <= 3:
                used.add(i.get("txn_id"))
                matched_out.add(o.get("txn_id"))
                findings.append(("WARN", "transfers",
                                 "Possible internal transfer {} <-> {}: {} {:.2f} on {} / {}".format(
                                     o.get("account"), i.get("account"),
                                     o.get("description", "")[:30], oamt,
                                     o.get("date"), i.get("date"))))
                break

    # 3b. Transfer-looking rows with no counter-entry (e.g. move to an account
    #     whose statement was not imported) - exclude from P&L, disclose here.
    for r in rows:
        tid = r.get("txn_id")
        if tid in used or tid in matched_out:
            continue
        if TRANSFER_RE.search(r.get("description", "") or ""):
            findings.append(("WARN", "transfers",
                             "Possible internal transfer with no matching counter-entry "
                             "(own-account transfer or a missing statement): {} {} {:.2f} on {}".format(
                                 r.get("account"), (r.get("description", "") or "")[:30],
                                 abs(_num(r.get("amount", 0)) or 0), r.get("date"))))

    # 4. Date coverage gaps (> 14 days with no transactions inside the span)
    dated = sorted([parse_date(r.get("date")) for r in rows if parse_date(r.get("date"))])
    if len(dated) >= 2:
        gaps = []
        for a, b in zip(dated, dated[1:]):
            if (b - a).days > 14:
                gaps.append((a, b))
        for a, b in gaps[:6]:
            findings.append(("WARN", "coverage",
                             "No transactions between {} and {} ({} days) - "
                             "a statement may be missing".format(a, b, (b - a).days)))

    # 5. Sign sanity per account
    per_account = defaultdict(lambda: [0, 0])
    for r in rows:
        amt = _num(r.get("amount", 0)) or 0
        acct = r.get("account", "?")
        if amt > 0:
            per_account[acct][0] += 1
        elif amt < 0:
            per_account[acct][1] += 1
    for acct, (ins, outs) in per_account.items():
        if ins == 0 and outs > 3:
            findings.append(("WARN", "signs",
                             "Account '{}' has {} outflows and zero inflows - "
                             "check sign convention or missing income rows".format(acct, outs)))

    # 6. Closing balance agreement
    for spec in args.closing:
        try:
            name, rest = spec.split("=", 1)
            date_s, bal_s = rest.split(":", 1)
            want = float(bal_s)
        except ValueError:
            findings.append(("WARN", "closing", "Malformed --closing spec: {}".format(spec)))
            continue
        acct_rows = [r for r in rows if r.get("account") == name.strip()
                     and parse_date(r.get("date")) and parse_date(r.get("date")) <= parse_date(date_s)]
        if not acct_rows:
            findings.append(("WARN", "closing",
                             "No rows for account '{}' before {}".format(name.strip(), date_s)))
            continue
        total = sum(_num(r.get("amount", 0)) or 0 for r in acct_rows)
        # Without an opening balance we can only verify net movement if provided as balance+income...
        # Instead: compare net movement against the change the user implies is impossible;
        # report the net so the human can confirm against the statement.
        diff = abs(total - want)
        if diff <= 0.01:
            findings.append(("PASS", "closing",
                             "Account '{}' nets {:.2f} which matches provided figure {}".format(
                                 name.strip(), total, want)))
        else:
            findings.append(("WARN", "closing",
                             "Account '{}': ledger net {:.2f} vs provided figure {:.2f} "
                             "(difference {:.2f}). If {:.2f} is the CLOSING balance, compare "
                             "against your statement's opening balance + net.".format(
                                 name.strip(), total, want, diff, want)))

    # 7. Unreviewed rows
    unrev = [r for r in rows if r.get("status") == "review" or r.get("category") in ("", "UNREVIEWED")]
    if unrev:
        findings.append(("WARN", "review",
                         "{} rows still need human categorization".format(len(unrev))))

    if not rows:
        findings.append(("FAIL", "empty", "Ledger has no rows."))

    order = {"FAIL": 0, "WARN": 1, "PASS": 2}
    findings.sort(key=lambda f: order[f[0]])
    fails = sum(1 for f in findings if f[0] == "FAIL")

    lines = ["# Reconciliation Report", "",
             "Rows checked: **{}**  |  FAIL: **{}**  |  WARN: **{}**  |  PASS: **{}**".format(
                 len(rows), fails,
                 sum(1 for f in findings if f[0] == "WARN"),
                 sum(1 for f in findings if f[0] == "PASS")),
             "", "| Level | Check | Detail |", "|---|---|---|"]
    for level, check, msg in findings:
        lines.append("| {} | {} | {} |".format(level, check, msg))
    if fails:
        lines += ["", "**Do not present P&L numbers until FAILs are resolved or explicitly disclosed.**"]
    else:
        lines += ["", "Ledger is safe to report on. Disclose any WARNs alongside reports."]

    out_dir = os.path.abspath(args.out)
    os.makedirs(os.path.join(out_dir, "out"), exist_ok=True)
    report_path = os.path.join(out_dir, "out", "reconciliation-report.md")
    with open(report_path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    print("FAIL:{} WARN:{} -> {}".format(
        fails, sum(1 for f in findings if f[0] == "WARN"), report_path))
    return 1 if fails else 0


def _num(s):
    try:
        return float(str(s).strip())
    except (TypeError, ValueError):
        return None


if __name__ == "__main__":
    sys.exit(main())
