# Network Response Deadlines (drift guard)

Version: 2026-10. **Unverified placeholders where marked.** Network rules change;
`ingest_dispute.py` prints a drift warning when this file is older than the
current date by more than 12 months, and always prefers the respond-by date in
the dispute record over anything in this file.

## Defaults when the export has no respond-by date

| Source | Typical window from dispute open | Note |
|---|---|---|
| Stripe | 7-21 days (Stripe shows an exact "respond by" date per dispute) | Use the dashboard date when present |
| PayPal | 10 days for most disputes, 20 for some claim types | Placeholder, verify per case |
| Shopify Payments | Follows Stripe-style windows | Placeholder |
| Square | 12 days typical | Placeholder, unverified |
| Visa direct (via acquirer) | 20 days for most reason codes | Placeholder, unverified |
| Mastercard (via acquirer) | 45 days for first chargeback response | Placeholder, unverified |
| GENERIC fallback | 10 days | Conservative default |

## Rules baked into ingest_dispute.py

1. If the record has `respond_by`, use it. Always.
2. Else use the source column above. Label the computed date as ESTIMATED
   everywhere it is shown.
3. If the computed/responded deadline is within 48 hours of now, the ingest
   report marks the dispute URGENT and it sorts to the top.
4. Never let a dispute age silently: `ingest_report.md` lists anything with
   3 days or less remaining.

## Why this file exists

Deadlines are the one part of a dispute that no amount of good evidence can
fix after the fact. Every output of this skill carries the deadline near the
top so it cannot be missed.
