# Normalized Statement Schema (statement.csv)

Written by `ingest_statement.py`; also hand-editable.

| Column | Type | Meaning |
|---|---|---|
| month | text | `YYYY-MM` the line belongs to |
| line_type | text | `volume` (card sales) or `fee` |
| card_type | text | For volume lines: `credit`, `debit`, `rewards`, `business`, `unknown` |
| present | text | `yes` (card-present), `no` (card-not-present), or `unknown` |
| description | text | Raw line description as it appeared on the statement |
| fee_key | text | Canonical key from `references/fee-dictionary.md`, or `other` |
| amount | decimal | Volume total or fee amount (always positive) |
| count | integer | Transaction count when the statement provides it (else blank) |

## Input formats the ingest script accepts

### CSV summary lines (preferred)

```csv
month,line_type,card_type,present,description,amount,count
2026-09,volume,credit,no,"VS CP CREDIT SALES",21430.55,310
2026-09,fee,,,DISCOUNT RATE,632.11,
2026-09,fee,,,PCI NON-COMP FEE,19.95,
```

If `line_type` is missing, the script infers it: lines whose description matches
a fee alias become `fee`, everything else with an amount becomes `volume`.

### Simple two-column text exports

```
2026-09 | VS CP CREDIT SALES | 21430.55
2026-09 | DISCOUNT RATE | 632.11
```

Pipe-, tab-, or comma-delimited: `month | description | amount`.

## Fee key mapping

Descriptions are uppercased and matched against the alias table (shared with
`references/fee-dictionary.md`). Unmatched fee lines keep `fee_key=other` and are
added to `out/review-queue.csv` so the human can classify once.
