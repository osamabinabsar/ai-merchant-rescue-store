#!/usr/bin/env python3
"""Self-check for the Chargeback Defense Kit.

Runs the full pipeline on bundled fixtures in a temp directory and asserts
expected outcomes. Run from the skill root:  python scripts/selfcheck.py
"""
from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
FIXTURES = ROOT / "tests" / "fixtures"

checks: list[tuple[bool, str]] = []


def check(ok: bool, label: str) -> None:
    checks.append((bool(ok), label))


def run(script: str, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(SCRIPTS / script), *args],
                          capture_output=True, text=True)


def load_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def main() -> int:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        cases_dir = tmp_path / "cases"

        # 1-3: fixtures sanity
        disputes = load_csv(FIXTURES / "sample-disputes.csv")
        check(len(disputes) == 3, "fixture has 3 disputes")
        evidence = load_csv(FIXTURES / "sample-evidence.csv")
        check(len(evidence) >= 7, "fixture has evidence rows")

        # Ingest
        r = run("ingest_dispute.py", str(FIXTURES / "sample-disputes.csv"),
                "--source", "stripe", "--out", str(cases_dir))
        check(r.returncode == 0, "ingest exits 0")
        register = cases_dir / "cases.csv"
        check(register.exists(), "cases.csv written")
        rows = load_csv(register)
        check(len(rows) == 3, "3 disputes registered")

        by_id = {r["dispute_id"]: r for r in rows}
        check(by_id["dp_1001"]["reason_code"] == "VISA-10.4", "fraudulent -> VISA-10.4")
        check(by_id["dp_1002"]["reason_code"] == "VISA-13.1", "product_not_received -> VISA-13.1")
        check(by_id["dp_1003"]["reason_code"] == "VISA-13.7", "subscription_canceled -> VISA-13.7")
        check(by_id["dp_1001"]["respond_by"] == "2026-10-04",
              "missing deadline computed from opened_on + 14 (stripe)")
        check(by_id["dp_1001"]["respond_by_estimated"] == "yes", "computed deadline labeled estimated")
        check(by_id["dp_1002"]["respond_by"] == "2026-10-10" and by_id["dp_1002"]["respond_by_estimated"] == "no",
              "provided deadline preserved, not estimated")
        check((cases_dir / "out" / "ingest-report.md").exists(), "ingest report written")

        # Idempotent re-ingest
        r2 = run("ingest_dispute.py", str(FIXTURES / "sample-disputes.csv"),
                 "--source", "stripe", "--out", str(cases_dir))
        check("skipped 3" in r2.stdout, "re-ingest skips duplicates")
        check(len(load_csv(register)) == 3, "register still has 3 rows after re-ingest")

        # Explicit network code normalization
        r3 = run("ingest_dispute.py", str(FIXTURES / "sample-disputes.csv"),
                 "--source", "generic", "--out", str(tmp_path / "cases2"))
        check(r3.returncode == 0, "generic ingest exits 0")
        g_rows = load_csv(tmp_path / "cases2" / "cases.csv")
        check(all(r["reason_code"] in ("VISA-10.4", "VISA-13.1", "VISA-13.7") for r in g_rows),
              "reason mapping stable across sources")

        # Evidence scoring
        ev_path = tmp_path / "evidence-index.csv"
        ev_path.write_text(FIXTURES.joinpath("sample-evidence.csv").read_text(encoding="utf-8"),
                           encoding="utf-8")
        r4 = run("evidence_check.py", "--cases", str(register),
                 "--evidence", str(ev_path), "--out", str(cases_dir / "out"))
        check(r4.returncode == 0, "evidence check exits 0")
        scorecard = (cases_dir / "out" / "evidence-scorecard.md").read_text(encoding="utf-8")
        check("dp_1001" in scorecard and "dp_1002" in scorecard, "scorecard covers disputes")
        check("Respond by" in scorecard, "scorecard shows deadline")

        missing = load_csv(cases_dir / "out" / "missing.csv")
        check(any(m["dispute_id"] == "dp_1002" and m["evidence_type"] == "proof_of_service"
                  for m in missing), "missing items listed for dp_1002")

        # dp_1001 is a strong packet: 4 present items on VISA-10.4 checklist
        line = [l for l in r4.stdout.splitlines() if l.startswith("dp_1001")]
        check(bool(line) and "READY" in line[0], "dp_1001 scored READY")
        line3 = [l for l in r4.stdout.splitlines() if l.startswith("dp_1003")]
        check(bool(line3) and "NEEDS EVIDENCE" in line3[0], "dp_1003 flagged as needing evidence")

        # Weak-item heuristic
        from evidence_check import is_weak  # type: ignore
        sys.path.insert(0, str(SCRIPTS))
        check(is_weak({"evidence_type": "delivery", "notes": "delivered"}) is True,
              "thin delivery note marked WEAK")
        check(is_weak({"evidence_type": "delivery", "notes": "UPS 1Z999, delivered 2026-09-22"}) is False,
              "tracking delivery note marked PRESENT")

        # Packet assembly
        r5 = run("assemble_packet.py", "--case", "dp_1001", "--cases", str(register),
                 "--evidence", str(ev_path), "--out", str(cases_dir / "out"))
        check(r5.returncode == 0, "packet assembly exits 0")
        packet = cases_dir / "out" / "packet-dp_1001"
        check((packet / "cover-letter.md").exists(), "cover letter written")
        check((packet / "evidence-index.md").exists(), "exhibit index written")
        manifest = json.loads((packet / "manifest.json").read_text(encoding="utf-8"))
        check(manifest["reason_code"] == "VISA-10.4", "manifest carries reason code")
        check(manifest["evidence_score"] >= 60, "manifest score computed")
        check(manifest["respond_by"] == "2026-10-04", "manifest carries deadline")
        letter = (packet / "cover-letter.md").read_text(encoding="utf-8")
        check("Exhibit" in letter and "{{" not in letter, "cover letter filled, no placeholders left")

        # Unknown dispute guard
        r6 = run("assemble_packet.py", "--case", "dp_9999", "--cases", str(register),
                 "--evidence", str(ev_path), "--out", str(cases_dir / "out"))
        check(r6.returncode != 0, "unknown dispute id rejected")

    passed = sum(1 for ok, _ in checks if ok)
    failed = [(label) for ok, label in checks if not ok]
    for ok, label in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {label}")
    print(f"\n{len(checks)} checks, {len(failed)} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
