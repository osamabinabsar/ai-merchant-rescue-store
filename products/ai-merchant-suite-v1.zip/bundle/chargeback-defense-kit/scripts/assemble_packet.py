#!/usr/bin/env python3
"""Assemble a representment packet for one dispute.

Builds out/packet-<dispute_id>/ with cover-letter.md (from the template),
evidence-index.md, and manifest.json. Deterministic; fills only known facts.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from evidence_check import CHECKLISTS, load_csv, score_dispute  # noqa: E402

ARGUMENT_SNIPPETS = {
    "avs_match": "The transaction passed address verification (AVS match).",
    "cvv_match": "The card's CVV code was verified at checkout.",
    "ip_device": "The purchase came from a device and IP address previously used on this account.",
    "account_history": "The account has prior undisputed orders, consistent with legitimate use.",
    "usage_after": "The account was used after the disputed purchase, which contradicts the claim.",
    "delivery": "The order was delivered and the carrier recorded delivery.",
    "proof_of_service": "The service or digital goods were made available to the customer.",
    "customer_communication": "The customer's own messages reference the order.",
    "product_description": "The product matched the description shown before purchase.",
    "terms": "The customer agreed to the posted terms at checkout.",
    "refund_attempt": "A refund was offered or processed per the posted policy.",
    "receipt": "An itemized receipt was issued at the time of purchase.",
    "transaction_records": "The transaction records show two distinct orders, not a duplicate charge.",
}


def build_cover_letter(template: str, case: dict, result: dict, exhibit_lines: list[str]) -> str:
    filled_events = []
    if case.get("opened_on"):
        filled_events.append(f"| {case['opened_on']} | Dispute opened ({case.get('reason_code')}) | processor record |")
    timeline_extra = "\n".join(filled_events)

    paragraphs = []
    for item in result["items"]:
        if item["status"] == "PRESENT" and item["key"] in ARGUMENT_SNIPPETS:
            paragraphs.append(ARGUMENT_SNIPPETS[item["key"]])
    if not paragraphs:
        paragraphs = ["Supporting exhibits are attached; see the evidence index below."]

    resp = case.get("respond_by") or "not available"
    note = " (estimated; confirm in the processor dashboard)" if case.get("respond_by_estimated") == "yes" else ""

    out = template
    replacements = {
        "{{dispute_id}}": case.get("dispute_id", "unknown"),
        "{{reason_code}}": case.get("reason_code", "GENERIC"),
        "{{amount}}": case.get("amount", "0"),
        "{{currency}}": case.get("currency", "USD"),
        "{{claim_summary}}": case.get("claim_summary") or "as stated in the dispute record",
        "{{one_line_finding}}": "the order was placed, fulfilled, and used by the customer",
        "{{order_date}}": case.get("opened_on", "not available"),
        "{{order_id}}": case.get("order_id", "not available"),
        "{{ex_receipt}}": "see exhibits",
        "{{fulfillment_date}}": "see exhibits",
        "{{fulfillment_event}}": "Order fulfilled",
        "{{ex_fulfillment}}": "see exhibits",
        "{{dispute_date}}": case.get("opened_on", "not available"),
        "{{extra_events}}": timeline_extra or "-",
        "{{argument_paragraphs}}": "\n\n".join(paragraphs),
        "{{exhibit_list}}": "\n".join(exhibit_lines),
        "{{merchant_contact}}": "merchant contact on file with the processor",
        "{{respond_by}}": resp,
        "{{deadline_note}}": note,
    }
    for k, v in replacements.items():
        out = out.replace(k, v)
    # Strip the assembly-rules footer.
    if "---\n\nAssembly rules" in out:
        out = out.split("---\n\nAssembly rules")[0].rstrip() + "\n"
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--case", required=True, help="dispute_id to assemble")
    ap.add_argument("--cases", default="cases/cases.csv")
    ap.add_argument("--evidence", default="cases/evidence-index.csv")
    ap.add_argument("--out", default="cases/out")
    args = ap.parse_args()

    cases = load_csv(Path(args.cases))
    evidence = load_csv(Path(args.evidence))
    case = next((c for c in cases if c.get("dispute_id") == args.case), None)
    if case is None:
        print(f"ERROR: dispute {args.case} not found in {args.cases}", file=sys.stderr)
        return 1

    result = score_dispute(case, evidence)
    packet_dir = Path(args.out) / f"packet-{args.case}"
    packet_dir.mkdir(parents=True, exist_ok=True)

    items = [e for e in evidence if e.get("dispute_id") == args.case]
    exhibit_lines, exhibit_map = [], {}
    for n, e in enumerate(items, start=1):
        exhibit_map[e["evidence_type"]] = f"Exhibit {n}"
        exhibit_lines.append(f"{n}. **Exhibit {n}** - {e.get('path_or_ref', '')}"
                             + (f" ({e['notes']})" if e.get("notes") else ""))

    template_path = Path(__file__).resolve().parent.parent / "templates" / "cover-letter.md"
    template = template_path.read_text(encoding="utf-8") if template_path.exists() else "{{exhibit_list}}"
    letter = build_cover_letter(template, case, result, exhibit_lines)
    (packet_dir / "cover-letter.md").write_text(letter, encoding="utf-8")

    index_lines = ["# Evidence Index", "", "| Exhibit | Type | File | Notes |", "|---|---|---|---|"]
    for n, e in enumerate(items, start=1):
        index_lines.append(f"| {n} | {e.get('evidence_type')} | {e.get('path_or_ref')} | {e.get('notes', '')} |")
    (packet_dir / "evidence-index.md").write_text("\n".join(index_lines) + "\n", encoding="utf-8")

    manifest = {
        "dispute_id": args.case,
        "reason_code": case.get("reason_code"),
        "amount": case.get("amount"),
        "currency": case.get("currency"),
        "respond_by": case.get("respond_by"),
        "respond_by_estimated": case.get("respond_by_estimated") == "yes",
        "evidence_score": result["score"],
        "ready_to_submit": result["viable"],
        "missing_blocking": [i["key"] for i in result["blocking"]],
        "assembled_on": date.today().isoformat(),
        "files": ["cover-letter.md", "evidence-index.md"],
    }
    (packet_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    state = "ready" if result["viable"] else "NOT ready (missing evidence)"
    print(f"Packet assembled: {packet_dir} (score {result['score']}/100, {state})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
