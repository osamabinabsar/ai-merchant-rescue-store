#!/usr/bin/env python3
"""Self-check for the Merchant Fee Audit skill.

Runs ingest -> audit -> negotiate on bundled fixtures in a temp directory and
asserts expected outcomes. Run from the skill root:  python scripts/selfcheck.py
"""
from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
FIXTURES = ROOT / "tests" / "fixtures"

checks: list[tuple[bool, str]] = []


def check(ok: bool, label: str) -> None:
    checks.append((bool(ok), label))


def run(script: str, *args: str) -> subprocess.CompletedProcess:
    return subprocess.run([sys.executable, str(SCRIPTS / script), *args],
                          capture_output=True, text=True)


def load_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def main() -> int:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        ws = tmp_path / "merchant-audit"

        fixture_rows = load_csv(FIXTURES / "sample-statement.csv")
        check(len(fixture_rows) == 21, "fixture has 21 statement lines")

        # Ingest
        r = run("ingest_statement.py", str(FIXTURES / "sample-statement.csv"), "--out", str(ws))
        check(r.returncode == 0, "ingest exits 0")
        register = ws / "statement.csv"
        check(register.exists(), "statement.csv written")
        rows = load_csv(register)
        check(len(rows) == 21, "21 lines normalized")
        by_desc = {r["description"]: r for r in rows}
        check(by_desc["DISCOUNT RATE"]["fee_key"] == "processor_markup", "DISCOUNT RATE -> processor_markup")
        check(by_desc["PCI NON-COMP FEE"]["fee_key"] == "pci_fee", "PCI NON-COMP FEE -> pci_fee")
        check(by_desc["STMT FEE"]["fee_key"] == "statement_fee", "STMT FEE -> statement_fee")
        check(by_desc["MIN FEE"]["fee_key"] == "monthly_minimum", "MIN FEE -> monthly_minimum")
        check(by_desc["WEIRD ISO PROGRAM FEE"]["fee_key"] == "other", "unknown fee -> review bucket")
        check((ws / "out" / "review-queue.csv").exists(), "review queue written")
        review = (ws / "out" / "review-queue.csv").read_text(encoding="utf-8")
        check("WEIRD ISO PROGRAM FEE" in review, "unknown fee listed for review")

        # Idempotent re-ingest
        r2 = run("ingest_statement.py", str(FIXTURES / "sample-statement.csv"), "--out", str(ws))
        check("skipped 21" in r2.stdout, "re-ingest skips duplicates")

        # Volume detection
        vol = by_desc["VS CNP CREDIT SALES"]
        check(vol["line_type"] == "volume" and vol["card_type"] == "credit", "sales line -> volume/credit")
        check(vol["present"] == "unknown" or vol["present"] in ("yes", "no"), "present flag populated")

        # Audit
        r3 = run("fee_audit.py", "--statement", str(register), "--out", str(ws / "out"))
        check(r3.returncode == 0, "fee audit exits 0")
        data = json.loads((ws / "out" / "audit-data.json").read_text(encoding="utf-8"))
        check(data["n_months"] == 3, "3 months audited")
        check(3.0 <= data["effective_rate"] <= 3.5, f"effective rate plausible ({data['effective_rate']}%)")
        check(data["benchmark_rate"] < data["effective_rate"], "benchmark below actual (overpaying)")
        check(data["total_volume"] == 95843.95, f"total volume exact ({data['total_volume']})")
        check(data["fee_totals"]["pci_fee"]["classification"] == "JUNK", "PCI fee classified JUNK")
        check(data["fee_totals"]["statement_fee"]["classification"] == "JUNK", "statement fee classified JUNK")
        check(data["junk_total"] == 98.7, f"junk total exact ({data['junk_total']})")
        check(data["savings_high"] > data["savings_low"] > 0, "savings range ordered and positive")
        check(2500 <= data["savings_high"] <= 3500, f"savings high plausible ({data['savings_high']})")
        report = (ws / "out" / "audit-report.md").read_text(encoding="utf-8")
        check("Effective rate" in report and "estimate" in report.lower(), "report shows rate and labels estimates")
        check("| 2026-07 |" in report, "monthly breakdown present")

        # Renegotiation letter
        r4 = run("negotiate_report.py", "--audit", str(ws / "out" / "audit-data.json"),
                 "--out", str(ws / "out"))
        check(r4.returncode == 0, "negotiate report exits 0")
        letter_path = ws / "out" / "renegotiation-letter.md"
        check(letter_path.exists(), "letter written")
        letter = letter_path.read_text(encoding="utf-8")
        check("{{" not in letter, "no placeholders left")
        check("3.2" in letter or "3.1" in letter or "3.3" in letter, "letter carries the effective rate")
        check("pci_fee" in letter and "statement_fee" in letter, "letter names the junk fees")
        check("10.0" not in letter.split("Subject")[0], "letter body sanity")

        # Missing audit guard
        r5 = run("negotiate_report.py", "--audit", str(tmp_path / "missing.json"), "--out", str(ws / "out"))
        check(r5.returncode != 0, "missing audit data rejected")

    passed = sum(1 for ok, _ in checks if ok)
    failed = [label for ok, label in checks if not ok]
    for ok, label in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {label}")
    print(f"\n{len(checks)} checks, {len(failed)} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
