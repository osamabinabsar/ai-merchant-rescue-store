#!/usr/bin/env python3
"""Ingest dispute exports (Stripe CSV, PayPal CSV, generic CSV/JSON) into cases.csv.

Stdlib only. Deterministic: same input -> same output, no network, no guessing.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

# Defaults from references/deadlines.md (placeholders labeled ESTIMATED downstream).
DEFAULT_WINDOWS = {
    "stripe": 14,
    "paypal": 10,
    "shopify": 14,
    "square": 12,
    "visa": 20,
    "mastercard": 45,
    "generic": 10,
}

FIELD_ALIASES = {
    "dispute_id": ["dispute_id", "case_id", "id", "dispute id", "case id", "disputeid"],
    "order_id": ["order_id", "invoice_id", "payment_id", "order id", "order", "invoice"],
    "amount": ["amount", "disputed_amount", "amount_refunded", "value", "dispute amount"],
    "currency": ["currency", "currency_code"],
    "reason_code": ["reason_code", "reason", "reason for dispute", "dispute_reason", "type"],
    "claim_summary": ["claim_summary", "reason_details", "customer_reason", "description", "note"],
    "opened_on": ["opened_on", "created", "created_date", "dispute_created", "opened", "date"],
    "respond_by": ["respond_by", "respond_by_date", "evidence_due_by", "due_by", "deadline"],
    "status": ["status", "state"],
}

REASON_MAP = [
    (r"fraud|unauthori[sz]ed", "VISA-10.4"),
    (r"not[_ ]received|product_not_received|undelivered", "VISA-13.1"),
    (r"not[_ ]as[_ ]described|unacceptable|defective|not_as_described", "VISA-13.3"),
    (r"cancell?ed|subscription_canceled|credit_not_processed", "VISA-13.7"),
    (r"duplicate", "VISA-13.2"),
]

NETWORK_CODE_RE = re.compile(r"(visa|mastercard|mc)[\s_-]*(\d{1,2}\.\d{1,2})", re.I)


def normalize_reason(raw: str) -> str:
    raw = (raw or "").strip()
    if not raw:
        return "GENERIC"
    m = NETWORK_CODE_RE.search(raw)
    if m:
        net = "VISA" if m.group(1).lower().startswith("v") else "MASTERCARD"
        return f"{net}-{m.group(2)}"
    low = raw.lower().replace("-", "_").replace(" ", "_")
    for pat, code in REASON_MAP:
        if re.search(pat, low):
            return code
    return "GENERIC"


def parse_date(raw: str) -> date | None:
    raw = (raw or "").strip()
    if not raw:
        return None
    raw = raw.split("T")[0].split(" ")[0]
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%Y/%m/%d", "%d-%b-%Y"):
        try:
            return datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    return None


def money(raw: str) -> str:
    cleaned = re.sub(r"[^0-9.\-]", "", raw or "")
    return cleaned or "0"


def read_rows(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    if path.suffix.lower() == ".json":
        data = json.loads(text)
        if isinstance(data, dict):
            data = data.get("data") or data.get("disputes") or [data]
        return [dict(row) for row in data]
    sample = text[:4096]
    delim = "\t" if text.count("\t") > text.count(",") else ","
    reader = csv.DictReader(text.splitlines(), delimiter=delim)
    return [dict(row) for row in reader]


def map_fields(row: dict) -> dict:
    lower = {str(k).strip().lower(): v for k, v in row.items() if k is not None}
    out = {}
    for field, aliases in FIELD_ALIASES.items():
        for alias in aliases:
            if alias in lower and lower[alias] not in (None, ""):
                out[field] = str(lower[alias]).strip()
                break
    return out


def normalize_row(row: dict, source: str) -> dict:
    f = map_fields(row)
    opened = parse_date(f.get("opened_on", ""))
    respond = parse_date(f.get("respond_by", ""))
    estimated = False
    if respond is None and opened is not None:
        window = DEFAULT_WINDOWS.get(source, DEFAULT_WINDOWS["generic"])
        respond = opened + timedelta(days=window)
        estimated = True
    return {
        "dispute_id": f.get("dispute_id", ""),
        "order_id": f.get("order_id", ""),
        "amount": money(f.get("amount", "")),
        "currency": (f.get("currency") or "USD").upper(),
        "reason_code": normalize_reason(f.get("reason_code", "")),
        "claim_summary": (f.get("claim_summary") or "").replace("\n", " ").strip()[:200],
        "opened_on": opened.isoformat() if opened else "",
        "respond_by": respond.isoformat() if respond else "",
        "respond_by_estimated": "yes" if estimated else "no",
        "source": source,
        "status": (f.get("status") or "open").lower(),
        "submitted_on": "",
    }


def drift_guard(ref_path: Path, today: date) -> str | None:
    if not ref_path.exists():
        return None
    m = re.search(r"Version:\s*(\d{4})-(\d{2})", ref_path.read_text(encoding="utf-8"))
    if not m:
        return None
    version = date(int(m.group(1)), int(m.group(2)), 1)
    months = (today.year - version.year) * 12 + (today.month - version.month)
    if months > 12:
        return (f"DRIFT WARNING: {ref_path.name} is {months} months old. "
                "Verify network deadlines before relying on computed dates.")
    return None


def write_report(out_dir: Path, rows: list[dict], warnings: list[str], added: int, skipped: int) -> None:
    today = date.today()
    urgent = [r for r in rows if r["respond_by"] and (date.fromisoformat(r["respond_by"]) - today).days <= 3]
    total = sum(float(r["amount"] or 0) for r in rows if r["status"] == "open")
    lines = [
        "# Dispute Ingest Report", "",
        f"- Rows added: {added}, duplicates skipped: {skipped}",
        f"- Total open money at stake: {total:.2f}",
        f"- Disputes with 3 days or less to respond: {len(urgent)}", "",
    ]
    for w in warnings:
        lines.append(f"> {w}")
    if warnings:
        lines.append("")
    lines.append("## Cases by urgency")
    def sort_key(r):
        return r["respond_by"] or "9999-12-31"
    lines.append("")
    lines.append("| Dispute | Amount | Reason | Opened | Respond by | Note |")
    lines.append("|---|---|---|---|---|---|")
    for r in sorted(rows, key=sort_key):
        note = "URGENT" if r in urgent else ("ESTIMATED deadline" if r["respond_by_estimated"] == "yes" else "")
        lines.append(f"| {r['dispute_id']} | {r['amount']} {r['currency']} | {r['reason_code']} "
                     f"| {r['opened_on']} | {r['respond_by']} | {note} |")
    (out_dir / "ingest-report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input", help="dispute export file (csv/tsv/json)")
    ap.add_argument("--source", default="auto", choices=["auto", "stripe", "paypal", "shopify", "square", "generic"])
    ap.add_argument("--out", default="cases", help="cases directory")
    args = ap.parse_args()

    src_path = Path(args.input)
    if not src_path.exists():
        print(f"ERROR: input file not found: {src_path}", file=sys.stderr)
        return 1
    source = args.source
    if source == "auto":
        name = src_path.name.lower()
        source = next((s for s in ("stripe", "paypal", "shopify", "square") if s in name), "generic")

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "out").mkdir(exist_ok=True)

    raw_rows = read_rows(src_path)
    normalized = [normalize_row(r, source) for r in raw_rows]
    normalized = [r for r in normalized if r["dispute_id"]]

    register = out_dir / "cases.csv"
    seen: set[str] = set()
    existing: list[dict] = []
    if register.exists():
        with register.open(newline="", encoding="utf-8") as fh:
            existing = list(csv.DictReader(fh))
        seen = {r.get("dispute_id", "") for r in existing}

    added = skipped = 0
    rows = list(existing)
    for r in normalized:
        if r["dispute_id"] in seen:
            skipped += 1
            continue
        seen.add(r["dispute_id"])
        rows.append(r)
        added += 1

    fieldnames = ["dispute_id", "order_id", "amount", "currency", "reason_code", "claim_summary",
                  "opened_on", "respond_by", "respond_by_estimated", "source", "status", "submitted_on"]
    with register.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k, "") for k in fieldnames})

    warnings = [w for w in [drift_guard(Path(__file__).resolve().parent.parent / "references" / "deadlines.md", date.today())] if w]
    write_report(out_dir / "out", rows, warnings, added, skipped)
    print(f"Ingested {added} new dispute(s), skipped {skipped} duplicate(s). Report: {out_dir}/out/ingest-report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
