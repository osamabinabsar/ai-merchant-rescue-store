# Bank Formats — parsing recipes

`scripts/ingest.py` auto-detects CSV/TSV, OFX/QFX, and JSON. This file covers
what to do when a statement doesn't fit: unusual columns, PDF text, and
statement layouts from around the world.

## 1. CSV column autodetection

Headers are matched after stripping case/spaces/punctuation:

| Field | Recognized headers |
|---|---|
| date | date, transaction date, posted date, value date, booking date, transacted on |
| description | description, details, payee, memo, name, narrative, reference, merchant |
| amount | amount, value, net, transaction amount |
| debit/credit | debit, withdrawal(s), money out, paid out, DR / credit, deposit(s), money in, paid in, CR |
| balance | balance, running balance, closing balance |
| currency | currency, curr, ccy |

If both debit and credit columns exist: `amount = credit − |debit|`.

**If detection fails**, don't guess: show the first 5 lines to the user, propose
a column order, and use a mapping file (below).

## 2. PDF statements (the common hard case)

Extract the statement text with the platform's PDF tooling into `raw/foo.txt`,
then map columns. Two mapping formats:

### a) Regex per line (best for clean text layers)

```json
{
  "format": "regex",
  "line": "^(?P<date>\\d{2}/\\d{2}/\\d{4})\\s+(?P<desc>[A-Za-z0-9 *.,&'/-]+?)\\s+(?P<amount>-?[\\d,]+\\.\\d{2})$"
}
```

```bash
python scripts/ingest.py raw/foo.txt --map mapping.json --account "Chase Checking" --out books/
```

### b) Fixed-width columns (best for monospaced statement dumps)

```json
{
  "format": "columns",
  "columns": [[0, 10], [10, 45], [45, 58]],
  "fields": ["date", "desc", "amount"]
}
```

### Worked example — common statement block

```
03/04/2026  META PLATFORMS *ADS             -250.00
03/06/2026  CLIENT ACME CORP  WIRE IN      3,200.00
```

Regex recipe: `^(?P<date>\d{2}/\d{2}/\d{4})\s{2,}(?P<desc>.+?)\s{2,}(?P<amount>-?[\d,]+\.\d{2})$`

**PDF failure modes:**
- *Table headers repeated per page* → the date regex naturally skips them; verify with the ingest report's row count vs. the statement's printed count.
- *Wrapped descriptions (two lines per txn)* → concatenate lines until a money-looking tail is found; simpler: extract per-page text, run a tiny preprocessing pass that joins lines not starting with a date.
- *Scanned image PDFs* → text extraction yields nothing. Tell the user this statement needs OCR or a CSV export; do not fabricate rows.

## 3. International date and amount conventions

- `31/12/2026` cannot be `MM/DD` — use `--date-order eu`. Ambiguous mid-year statements: ask the user which order their bank uses, once, and remember it in `rules.csv` notes.
- `1.234,56` (European) and `1,234.56` (Anglo) both parse automatically.
- `(50.00)` and `-50.00` and `50.00 DR` are all outflows; `50.00 CR` is an inflow.

## 4. Platform exports

| Source | Format | Notes |
|---|---|---|
| Stripe | CSV "Balance history" or JSON | Ingest **gross charges and fees as separate rows** or revenue will be netted |
| PayPal | CSV (Activity download) | Includes "Currency conversion" rows → Bank & Payment Fees |
| Wise / Revolut | CSV / OFX | Multi-currency: keep `currency` column; don't convert silently |
| Shopify | CSV payouts | Payout ≠ revenue; reconcile payout periods |
| QuickBooks / Xero | CSV export | Usually well-formed; map "Name" to description |

## 5. Counting to verify

Always compare the ingest report's `Added` count against the statement's own
"number of transactions" or last-row balance. A quiet off-by-one is how missing
pages survive to April.
