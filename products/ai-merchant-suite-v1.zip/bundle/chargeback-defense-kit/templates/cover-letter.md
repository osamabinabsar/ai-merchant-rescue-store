# Cover Letter Template

Subject: Representment for dispute {{dispute_id}} - {{reason_code}} - {{amount}} {{currency}}

To the issuing bank / dispute reviewer,

We are contesting the above dispute. The cardholder's claim is that
{{claim_summary}}. The attached exhibits show {{one_line_finding}}.

## Timeline

| Date | Event | Exhibit |
|---|---|---|
| {{order_date}} | Order placed ({{order_id}}) | {{ex_receipt}} |
| {{fulfillment_date}} | {{fulfillment_event}} | {{ex_fulfillment}} |
| {{dispute_date}} | Dispute opened ({{reason_code}}) | processor record |
| {{extra_events}} | | |

## Response to the claim

{{argument_paragraphs}}

Each statement above is supported by the numbered exhibits below. We ask that
the dispute be decided in the merchant's favor.

## Exhibits

{{exhibit_list}}

Merchant contact: {{merchant_contact}}
Response deadline: {{respond_by}}{{deadline_note}}

---

Assembly rules (for the agent, delete this section before submitting):

- `{{argument_paragraphs}}`: one paragraph per claim point from the playbook,
  each ending with "(Exhibit N)". Factual tone, no accusations.
- `{{exhibit_list}}`: numbered, captioned, matching the exhibit numbers used
  in the argument. Include only items in `evidence-index.csv`.
- If the scorecard has MISSING items with weight >= 3, warn the human before
  finalizing and list what to gather.
- Never fill a placeholder with an assumption. If a date is unknown, write
  "not available" and tell the user.
