---
name: bookkeeping-rescue
description: "Turn bank and credit-card statements (CSV, OFX/QFX, JSON exports, or text from PDF statements) into tax-ready books: a categorized ledger reconciled against statement balances, with a P&L, a deductible summary mapped to tax lines, and an accountant-ready tax packet. For solopreneurs, freelancers, and small businesses. Deterministic bundled scripts do the parsing, rules-based categorization, duplicate and transfer detection, and reconciliation - every number traces to a source row and none is invented. Use when the user wants to organize or categorize bank transactions, do bookkeeping, catch up months of statements, find what is deductible, prepare expenses for taxes, get a P&L / profit and loss, reconcile an account, or says \"bookkeeping\", \"bank statement\", \"tax season\", \"categorize expenses\", \"what can I deduct\", \"catch up my books\". Do NOT use for tax filing or legal advice, investment decisions, or budgets with no transaction data."
---

# Bookkeeping Rescue

Turn statements into books a real bookkeeper would sign off on: **parsed once, categorized by rules, reconciled against balances, and fully traceable**.

This skill is reliable by construction. The heavy lifting runs through bundled deterministic Python scripts (stdlib only, no dependencies). The model orchestrates, explains, and handles the small judgment queue — it never does arithmetic in its head and never invents numbers.

## The reliability contract (never break these)

1. **No fabricated numbers.** Every figure in any report must come from `report.py` or `reconcile.py` output. Never restate totals from memory; re-run the script.
2. **No guessing personal vs. business.** Mixed or ambiguous charges go to the review queue. The human decides. One approval = one new rule.
3. **Full traceability.** Every ledger row keeps `source_file` and `source_row`. If the user asks "where did this number come from?", show them the source rows.
4. **Reconcile or refuse to report.** If `reconcile.py` has FAIL items, fix or disclose them before presenting P&L numbers.
5. **Year-check the rate card.** Before any deduction or mileage figure, verify `references/rate-card.md` matches the tax year in play. If it doesn't, say so and use it only as a labeled placeholder.
6. **No tax advice.** General categorization only. For filing positions, elections, or "can I deduct X" edge cases, the answer is "categorize it, flag it, ask your CPA" — and put it in the packet's Questions-for-CPA list.

## Workspace layout

Create a `books/` folder wherever the user keeps the data:

```
books/
  raw/            # statements exactly as received (read-only)
  ledger.csv      # normalized transactions (schema in templates/ledger-schema.md)
  rules.csv       # categorization rules, learned + seeded (templates/rules.example.csv)
  out/            # generated reports
```

## Workflow

### Phase 0 — Setup
Ask (once): tax year, country profile (US Schedule C / UK self-assessment / generic), base currency, and which accounts are business vs. personal. Copy `templates/rules.example.csv` to `books/rules.csv` if none exists.

### Phase 1 — Ingest
For each statement file:

```bash
python scripts/ingest.py <statement.csv|ofx|qfx|json> --account "Chase Checking" --out books/ --year 2026
```

- CSV/TSV, OFX/QFX, and JSON (Stripe/PayPal-style) are parsed automatically.
- **PDF statements:** extract the text with the platform's PDF tooling into `raw/foo.txt`, then run `ingest.py raw/foo.txt --map mapping.json` where `mapping.json` describes the columns (see `references/bank-formats.md` for the mapping recipe and worked example).
- The script normalizes dates and amounts, strips currency symbols, fingerprints each row for dedupe, and appends to `books/ledger.csv`.
- Read `books/out/ingest-report.md` aloud to the user in summary: rows added, duplicates skipped, rows needing attention.

### Phase 2 — Categorize (rules, not vibes)

```bash
python scripts/categorize.py --ledger books/ledger.csv --rules books/rules.csv --out books/
```

Deterministic layer first: ordered rules, then the built-in merchant taxonomy. Anything unmatched lands in `out/review-queue.csv` with **suggested** keywords highlighted.

Model layer second: for each review-queue row, propose a category from `references/category-taxonomy.md` and explain why in one line. **Present suggestions to the human for approval — never auto-approve.** When the user approves or corrects a call, add a rule to `books/rules.csv` (match on the merchant keyword), so the decision is made exactly once.

### Phase 3 — Reconcile

```bash
python scripts/reconcile.py --ledger books/ledger.csv --closing "Chase Checking=2026-03-31:4821.12" --out books/
```

Checks: duplicate fingerprints, suspected internal transfers (same amount, opposite sign, ≤3 days apart across accounts), date-coverage gaps, sign sanity, and closing-balance agreement when balances are provided. Fix FAILs by re-ingesting or annotating; disclose any remaining WARNs every time reports are shown.

### Phase 4 — Report

```bash
python scripts/report.py --ledger books/ledger.csv --year 2026 --out books/out/
```

Produces: `pnl.md` + `pnl.csv` (monthly and YTD, income/expense by category), `deductions.md` (deductible totals mapped to tax lines), `tax-packet.md` (the bundle to hand a CPA: P&L, deductions, open questions, substantiation gaps), and `cashflow.md`. Hand the user `out/tax-packet.md` and offer the CSVs.

### Phase 5 — The weekly ritual (sell the habit, not just the dump)
When the user finishes a catch-up, propose the 10-minute weekly close from `references/workflow.md`: import the week's rows, clear the review queue, add one or two rules. Categorizing the day it happened takes seconds; archaeology in April takes weekends.

## Failure modes to handle explicitly

- **Unknown file layout:** don't guess columns silently — show the first 5 lines, propose a `--map`, confirm, then ingest. (`references/bank-formats.md`)
- **Balance mismatch > 0.01:** report the exact gap; never nudge numbers to force agreement.
- **Mixed personal/business:** split is a human call; default to `Review` with both options priced out.
- **Multi-currency:** keep original amounts in `notes`; convert only at the user's explicit instruction and record the rate used.

## References

Load on demand, not up front:
- `references/category-taxonomy.md` — chart of accounts ↔ tax-line mapping
- `references/deduction-rules.md` — deductibility heuristics + substantiation rules
- `references/rate-card.md` — current-year rates with drift guard
- `references/bank-formats.md` — parsing recipes + PDF text-mapping examples
- `references/workflow.md` — weekly ritual, monthly close, year-end packet
