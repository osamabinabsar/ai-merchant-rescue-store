# Ledger schema (`books/ledger.csv`)

One row per transaction. The ledger is the single source of truth — reports are
generated from it and never edited by hand.

| Column | Type | Meaning |
|---|---|---|
| txn_id | hex16 | Deterministic fingerprint (date + description + amount + account). Used for dedupe; stable across re-ingests. |
| date | YYYY-MM-DD | Normalized posting date. |
| description | text | Normalized payee/merchant line (whitespace collapsed). |
| amount | decimal(2) | Signed: negative = outflow, positive = inflow. Original currency. |
| currency | ISO-4217 or blank | Blank = account's base currency. |
| account | text | Account name passed via `--account`. Keep one ledger per legal entity. |
| memo | text | Original memo/reference from the bank. |
| source_file | text | Statement file the row came from. |
| source_row | int | Row/line number inside that file. Together with source_file = audit trail. |
| category | text | From the taxonomy; `UNREVIEWED` until a human decides. |
| status | enum | `unreviewed` → `review` → `auto` (rule matched) or `approved` (human confirmed). |
| confidence | 0.00–1.00 | Rule = 0.95, taxonomy = 0.90, heuristic = 0.70–0.80. Informational only. |
| notes | text | Freeform; `tax_line:<name>` is parsed by report.py for the deductions summary. |

## Invariants (reconcile.py enforces these)

1. No duplicate `txn_id` values.
2. All dates parse; all amounts parse.
3. Splits (mixed personal/business) are two rows whose amounts sum to the
   original, each with a `note: split <reason>`.
4. Nothing is deleted to make a report look better — corrections are new rows
   or edits with the reason in `notes`.
